package com.example.replica.data

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.replica.domain.AcceptRule
import com.example.replica.domain.TripRecord
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/** Instrumented (runs on a device/emulator): in-memory Room database. */
@RunWith(AndroidJUnit4::class)
class TripLogDaoTest {
    private lateinit var db: AppDatabase
    private lateinit var repo: TripLogRepository
    private var now = 100L * 86_400_000L

    @Before fun open() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(ctx, AppDatabase::class.java).allowMainThreadQueries().build()
        repo = TripLogRepository(db.tripLogDao()) { now }
    }
    @After fun close() = db.close()

    private fun trip(at: Long, price: Double? = 3.0, dest: String? = "A") =
        TripRecord(acceptedAtMs = at, price = price, destination = dest, pickupMinutes = 3, rule = AcceptRule.NORMAL, sourcePackage = "p")

    @Test fun insertedTrips_comeBackNewestFirst() = runBlocking {
        repo.record(trip(1_000, dest = "old")); repo.record(trip(500_000, dest = "new"))
        assertEquals(listOf("new", "old"), repo.trips.first().map { it.destination })
    }

    @Test fun nullablePrice_andDestination_roundTrip() = runBlocking {
        repo.record(trip(1_000, price = null, dest = null))
        val r = repo.trips.first().single(); assertNull(r.price); assertNull(r.destination)
    }

    @Test fun duplicateInsideAMinute_isSkipped() = runBlocking {
        assertTrue(repo.record(trip(1_000))); assertFalse(repo.record(trip(20_000)))
        assertEquals(1, repo.trips.first().size)
    }

    @Test fun prune_removesOnlyOldTrips() = runBlocking {
        repo.record(trip(now - 91L * 86_400_000L, dest = "old")); repo.record(trip(now - 1_000, dest = "recent"))
        assertEquals(1, repo.prune())
        assertEquals(listOf("recent"), repo.trips.first().map { it.destination })
    }

    @Test fun clear_emptiesTheLog() = runBlocking {
        repo.record(trip(1_000)); repo.clear(); assertTrue(repo.trips.first().isEmpty())
    }

    @Test fun todayCount_countsOnlyTripsSinceLocalMidnight() = runBlocking {
        now += 12 * 3_600_000L   // noon UTC on day 100
        repo.record(trip(now - 1_000, dest = "today")); repo.record(trip(now - 2 * 86_400_000L, dest = "old"))
        assertEquals(1, repo.todayCount(java.time.ZoneOffset.UTC).first())
    }
}
