package com.example.replica.domain

import org.junit.Assert.assertEquals
import org.junit.Test

class DecisionEngineTest {
    private val on = Settings(autoAcceptEnabled = true) // defaults: min price 2.0, max pickup 5 min

    private fun accept(rule: AcceptRule) = Decision.Accept(rule)
    private fun ignore(reason: IgnoreReason) = Decision.Ignore(reason)
    private fun run(price: Double?, pickup: Int?, s: Settings = on, entitled: Boolean = true) =
        DecisionEngine.evaluate(Offer(price, pickup), s, entitled)

    @Test fun autoAcceptOff_ignores() =
        assertEquals(ignore(IgnoreReason.AUTO_ACCEPT_OFF), run(5.0, 2, on.copy(autoAcceptEnabled = false)))

    @Test fun notEntitled_ignoresEvenWhenOn() =
        assertEquals(ignore(IgnoreReason.NOT_ENTITLED), run(5.0, 2, entitled = false))

    @Test fun normalAccept() = assertEquals(accept(AcceptRule.NORMAL), run(3.0, 4))
    @Test fun priceBelowMin_ignored() = assertEquals(ignore(IgnoreReason.PRICE_TOO_LOW), run(1.5, 2))
    @Test fun priceEqualsMin_accepted() = assertEquals(accept(AcceptRule.NORMAL), run(2.0, 3))
    @Test fun pickupEqualsMax_accepted() = assertEquals(accept(AcceptRule.NORMAL), run(3.0, 5))
    @Test fun pickupAboveMax_ignored() = assertEquals(ignore(IgnoreReason.PICKUP_TOO_FAR), run(3.0, 6))

    @Test fun minPriceDisabled_lowPriceAccepted() =
        assertEquals(accept(AcceptRule.NORMAL), run(0.5, 3, on.copy(minPriceEnabled = false)))

    @Test fun maxPickupDisabled_farPickupAccepted() =
        assertEquals(accept(AcceptRule.NORMAL), run(3.0, 30, on.copy(maxPickupEnabled = false)))

    @Test fun unknownPickup_withMaxEnabled_ignored() =
        assertEquals(ignore(IgnoreReason.PICKUP_UNKNOWN), run(3.0, null))

    @Test fun unknownPickup_withMaxDisabled_accepted() =
        assertEquals(accept(AcceptRule.NORMAL), run(3.0, null, on.copy(maxPickupEnabled = false)))

    // price overrides time
    private val override7 = on.copy(priceOverrideTimeEnabled = true, priceOverrideTimeValue = 7.0)

    @Test fun priceOverride_skipsTimeRule() =
        assertEquals(accept(AcceptRule.PRICE_OVERRIDES_TIME), run(7.0, 12, override7))

    @Test fun priceOverride_belowThreshold_timeStillApplies() =
        assertEquals(ignore(IgnoreReason.PICKUP_TOO_FAR), run(6.9, 12, override7))

    @Test fun priceOverride_doesNotBypassMinPrice() =
        assertEquals(ignore(IgnoreReason.PRICE_TOO_LOW), run(7.5, 12, override7.copy(minPrice = 8.0)))

    @Test fun priceOverride_whenTimeAlreadyOk_isNormal() =
        assertEquals(accept(AcceptRule.NORMAL), run(8.0, 3, override7))

    // short-trip override (user-confirmed: pickup 1-2 min beats the min-price rule)
    private val short = on.copy(shortTripOverrideEnabled = true)

    @Test fun shortTrip_pickup2_lowPriceAccepted() =
        assertEquals(accept(AcceptRule.SHORT_TRIP_OVERRIDE), run(1.0, 2, short))

    @Test fun shortTrip_pickup1_lowPriceAccepted() =
        assertEquals(accept(AcceptRule.SHORT_TRIP_OVERRIDE), run(1.0, 1, short))

    @Test fun shortTrip_pickup3_notCovered() =
        assertEquals(ignore(IgnoreReason.PRICE_TOO_LOW), run(1.0, 3, short))

    @Test fun shortTrip_disabled_lowPriceIgnored() =
        assertEquals(ignore(IgnoreReason.PRICE_TOO_LOW), run(1.0, 1))

    // offers without a price
    @Test fun noPrice_whenNotAllowed_ignored() =
        assertEquals(ignore(IgnoreReason.NO_PRICE_NOT_ALLOWED), run(null, 3))

    @Test fun noPrice_allowed_timeOk_accepted() =
        assertEquals(accept(AcceptRule.NO_DESTINATION_TIME_ONLY), run(null, 3, on.copy(acceptNoDestinationEnabled = true)))

    @Test fun noPrice_allowed_timeTooFar_ignored() =
        assertEquals(ignore(IgnoreReason.PICKUP_TOO_FAR), run(null, 9, on.copy(acceptNoDestinationEnabled = true)))

    // bad input
    @Test fun negativePrice_invalid() = assertEquals(ignore(IgnoreReason.INVALID_OFFER), run(-1.0, 2))
    @Test fun nanPrice_invalid() = assertEquals(ignore(IgnoreReason.INVALID_OFFER), run(Double.NaN, 2))
    @Test fun negativePickup_invalid() = assertEquals(ignore(IgnoreReason.INVALID_OFFER), run(3.0, -1))
}
