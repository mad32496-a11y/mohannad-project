package com.example.replica.domain

import org.junit.Assert.*
import org.junit.Test

class HomeStateTest {
    private fun s(auto: Boolean, connected: Boolean, app: Boolean) = HeroState.from(auto, connected, app)

    @Test fun off_isStopped_whatever_theRest() {
        for (c in listOf(true, false)) for (a in listOf(true, false)) assertEquals(HeroState.STOPPED, s(false, c, a))
    }
    @Test fun on_connected_withApp_isRunning() = assertEquals(HeroState.RUNNING, s(true, true, true))
    @Test fun on_notConnected_needsAccessibility_evenWithApp() {
        assertEquals(HeroState.NEEDS_ACCESSIBILITY, s(true, false, true)); assertEquals(HeroState.NEEDS_ACCESSIBILITY, s(true, false, false))
    }
    @Test fun on_connected_noApp_needsApp() = assertEquals(HeroState.NEEDS_APP, s(true, true, false))

    @Test fun actions_perState() {
        assertEquals(HeroAction.TURN_ON, HeroState.STOPPED.primaryAction)
        assertEquals(HeroAction.TURN_OFF, HeroState.RUNNING.primaryAction)
        assertEquals(HeroAction.OPEN_ACCESSIBILITY, HeroState.NEEDS_ACCESSIBILITY.primaryAction)
        assertEquals(HeroAction.TURN_OFF, HeroState.NEEDS_APP.primaryAction)
    }

    @Test fun drawer_releaseBuild_hidesSimulator() =
        assertEquals(listOf(DrawerDestination.HOME, DrawerDestination.TRIP_LOG), DrawerDestinations.visible(false))
    @Test fun drawer_debugBuild_showsSimulatorLast() {
        val v = DrawerDestinations.visible(true)
        assertEquals(DrawerDestination.SIMULATOR, v.last()); assertEquals(3, v.size)
    }
    @Test fun drawer_homeIsFirst() = assertEquals(DrawerDestination.HOME, DrawerDestinations.visible(false).first())
}
