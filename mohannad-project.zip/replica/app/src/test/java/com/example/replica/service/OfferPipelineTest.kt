package com.example.replica.service

import com.example.replica.domain.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class OfferPipelineTest {
    private var t = 0L
    private val log = mutableListOf<DecisionEntry>()
    private var settings = Settings(autoAcceptEnabled = true)
    private var clickResult = true
    private var clicks = 0

    private fun pipeline() = OfferPipeline({ settings }, { true }, { t }, 3_000, { log += it })
    private fun offer(price: Double? = 3.0, pickup: Int? = 3, dest: String? = "A") =
        ParsedOffer(Offer(price, pickup), dest) { clicks++; clickResult }

    @Test fun acceptedOffer_isClickedOnce_andLogged() {
        pipeline().handle(offer())
        assertEquals(1, clicks); assertEquals(1, log.size)
        assertEquals(Decision.Accept(AcceptRule.NORMAL), log[0].decision); assertEquals(true, log[0].clicked)
    }

    @Test fun ignoredOffer_isNotClicked() {
        pipeline().handle(offer(price = 0.5))
        assertEquals(0, clicks); assertEquals(Decision.Ignore(IgnoreReason.PRICE_TOO_LOW), log[0].decision); assertNull(log[0].clicked)
    }

    @Test fun autoAcceptOff_noClick() {
        settings = settings.copy(autoAcceptEnabled = false)
        pipeline().handle(offer())
        assertEquals(0, clicks); assertEquals(Decision.Ignore(IgnoreReason.AUTO_ACCEPT_OFF), log[0].decision)
    }

    @Test fun duplicateInsideWindow_handledOnce() {
        val p = pipeline(); p.handle(offer()); t = 1_000; p.handle(offer())
        assertEquals(1, clicks); assertEquals(1, log.size)
    }

    @Test fun duplicateAfterWindow_handledAgain() {
        val p = pipeline(); p.handle(offer()); t = 3_500; p.handle(offer())
        assertEquals(2, clicks); assertEquals(2, log.size)
    }

    @Test fun failedClick_allowsImmediateRetry() {
        clickResult = false
        val p = pipeline(); p.handle(offer()); t = 100; p.handle(offer())
        assertEquals(2, clicks); assertEquals(false, log[0].clicked)
    }

    @Test fun differentOffers_areHandledSeparately() {
        val p = pipeline(); p.handle(offer(price = 3.0)); t = 100; p.handle(offer(price = 4.0))
        assertEquals(2, clicks)
    }

    @Test fun sourcePackage_isCopiedIntoTheLog() {
        pipeline().handle(ParsedOffer(Offer(3.0, 3), "A", "com.ride.app") { true })
        assertEquals("com.ride.app", log[0].sourcePackage)
    }
}
