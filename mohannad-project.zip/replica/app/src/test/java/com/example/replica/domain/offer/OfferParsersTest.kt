package com.example.replica.domain.offer

import com.example.replica.domain.DumpNode
import org.junit.Assert.*
import org.junit.Test

/**
 * SYNTHETIC trees: built by hand from what was visible in four screenshots, with placeholder addresses.
 * They prove the parsing logic, not that the real apps expose these nodes. Replace them with real captures.
 */
class OfferParsersTest {
    private fun node(
        label: String? = null, top: Int = 0, left: Int = 0, clickable: Boolean = false, viaDesc: Boolean = false,
        enabled: Boolean = true, visible: Boolean = true, bounds: List<Int>? = null, kids: List<DumpNode> = emptyList(),
    ) = DumpNode(
        "android.view.View", null, if (viaDesc) null else label, if (viaDesc) label else null, null,
        bounds ?: listOf(left, top, left + 400, top + 60), clickable, enabled, false, false, false, false, visible, kids,
    )

    private fun screen(vararg kids: DumpNode) = node(top = 0, bounds = listOf(0, 0, 600, 1320), kids = kids.toList())
    private fun button(label: String, top: Int, viaDesc: Boolean = false) =
        node(top = top, clickable = true, bounds = listOf(40, top, 560, top + 85), kids = listOf(node(label, top + 15, 200, viaDesc = viaDesc)))

    // ---- Jeeny
    private fun jeenyOffer(accept: DumpNode = button("قبول العرض", 1170)) = screen(
        node("إيكونومي", 620), node("يبعُد 1 دقائق", 700), node("يبعُد ام", 770), node("JOD 1.50", 880),
        node("Pickup Street - Area", 1020), node("Dropoff Street 47", 1100), accept,
    )

    @Test fun jeeny_offer_isParsed() {
        val o = JeenyScreenParser().parse(jeenyOffer())!!
        assertEquals(1.5, o.offer.price!!, 0.0); assertEquals(1, o.offer.pickupMinutes)
        assertEquals("Dropoff Street 47", o.destination)
        assertEquals("قبول العرض", o.accept.label); assertEquals(listOf(40, 1170, 560, 1255), o.accept.bounds)
    }

    @Test fun jeeny_idleScreen_isNotAnOffer() =
        assertNull(JeenyScreenParser().parse(screen(node("JOD 2.31", 100), node("إيقاف", 100, 40, clickable = true), node("أنت متاح الآن", 1160))))

    @Test fun jeeny_labelInContentDescription_isStillRead() =
        assertEquals(1.5, JeenyScreenParser().parse(jeenyOffer(button("قبول العرض", 1170, viaDesc = true)))!!.offer.price!!, 0.0)

    @Test fun jeeny_mergedLabel_isStillRead() {
        val o = JeenyScreenParser().parse(screen(node("إيكونومي\nيبعُد 1 دقائق\nJOD 1.50", 700), button("قبول العرض", 1170)))!!
        assertEquals(1.5, o.offer.price!!, 0.0); assertEquals(1, o.offer.pickupMinutes)
    }

    @Test fun jeeny_acceptWordNotInsideAButton_isNotAnOffer() =
        assertNull(JeenyScreenParser().parse(screen(node("JOD 1.50", 880), node("قبول العرض", 1190))))

    @Test fun jeeny_disabledButton_isNotAnOffer() =
        assertNull(JeenyScreenParser().parse(screen(node("JOD 1.50", 880), node(top = 1170, clickable = true, enabled = false, kids = listOf(node("قبول العرض", 1190))))))

    @Test fun jeeny_offscreenNodes_areIgnored() =
        assertNull(JeenyScreenParser().parse(screen(node("JOD 1.50", 880, visible = false), button("قبول العرض", 1170))))

    @Test fun jeeny_buttonWithoutNumbers_isNotAnOffer() = assertNull(JeenyScreenParser().parse(screen(button("قبول العرض", 1170))))

    // ---- Petra
    private fun petraOffer(extra: List<DumpNode> = emptyList()) = screen(
        node("رفض", 95, 25, clickable = true, bounds = listOf(25, 95, 190, 140)),
        node("تاكسي", 780), node("1.44 د.أ", 880), node("نقطة الانطلاق", 960), node("2.88 دقيقة • 830 متر", 960, 300),
        node("شارع أ, الأردن", 990), node("نقطة الوصول", 1045), node("شارع ب, منطقة ج, الأردن", 1070),
        button("قبول", 1140), *extra.toTypedArray(),
    )

    @Test fun petra_offer_isParsed() {
        val o = PetraScreenParser().parse(petraOffer())!!
        assertEquals(1.44, o.offer.price!!, 0.0)
        assertEquals(3, o.offer.pickupMinutes)                  // 2.88 minutes rounds up, so the 1-2 minute rule does not fire
        assertEquals("شارع ب, منطقة ج, الأردن", o.destination)
        assertEquals("قبول", o.accept.label)
    }

    @Test fun petra_neverPicksTheRejectButton() = assertNotEquals("رفض", PetraScreenParser().parse(petraOffer())!!.accept.label)

    @Test fun petra_idleScreen_isNotAnOffer() =
        assertNull(PetraScreenParser().parse(screen(node("8.42 د.أ", 185), node("أنا متاح", 1030), button("انتقل إلى وضع عدم الإتاحة", 1160))))

    @Test fun petra_destinationLabelAndValueMerged() {
        val o = PetraScreenParser().parse(screen(node("1.44 د.أ", 880), node("2 دقيقة", 960), node("نقطة الوصول\nشارع ب", 1045), button("قبول", 1140)))!!
        assertEquals("شارع ب", o.destination)
    }

    @Test fun petra_wholeMinute_staysWhole() =
        assertEquals(3, PetraScreenParser().parse(screen(node("1.44 د.أ", 880), node("3 دقيقة", 960), button("قبول", 1140)))!!.offer.pickupMinutes)

    @Test fun petra_halfMinute_roundsUpToOne() =
        assertEquals(1, PetraScreenParser().parse(screen(node("1.44 د.أ", 880), node("0.5 دقيقة", 960), button("قبول", 1140)))!!.offer.pickupMinutes)

    // ---- text helpers
    @Test fun price_formats() {
        assertEquals(1.5, OfferText.price("JOD 1.50")!!, 0.0)
        assertEquals(1.44, OfferText.price("1.44 د.أ")!!, 0.0)
        assertEquals(2.0, OfferText.price("JD 2")!!, 0.0)
        assertEquals(1.5, OfferText.price("١٫٥ د.أ")!!, 0.0)
        assertEquals(2.5, OfferText.price("2,5 دينار")!!, 0.0)
        assertEquals(3.0, OfferText.price("3 د . أ")!!, 0.0)
    }
    @Test fun price_notFound() { assertNull(OfferText.price("830 متر")); assertNull(OfferText.price("إيكونومي")) }

    @Test fun pickup_formats() {
        assertEquals(1, OfferText.pickupMinutes("يبعُد 1 دقائق"))
        assertEquals(3, OfferText.pickupMinutes("2.88 دقيقة • 830 متر"))
        assertEquals(5, OfferText.pickupMinutes("5 min"))
        assertEquals(4, OfferText.pickupMinutes("٣٫٥ دقيقة"))
    }
    @Test fun pickup_metresAreNotMinutes() { assertNull(OfferText.pickupMinutes("830 متر")); assertNull(OfferText.pickupMinutes("1.2 كم")) }

    @Test fun clean_dropsDiacriticsAndBidiMarks() = assertEquals("يبعد 1", OfferText.clean("\u200Fيبعُدَ   1"))

    // ---- app detection
    @Test fun detect_roles() {
        assertEquals(RideApp.JEENY, RideApp.detect("Jeeny Driver", "x.y"))
        assertEquals(RideApp.PETRA, RideApp.detect("Petra Safeer", "x.y"))
        assertEquals(RideApp.PETRA, RideApp.detect("سائق", "com.PetraRide_Driver"))
        assertNull(RideApp.detect("Careem Captain", "com.careem.captain"))
    }
}
