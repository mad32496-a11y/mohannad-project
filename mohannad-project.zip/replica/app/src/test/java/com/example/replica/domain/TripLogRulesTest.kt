package com.example.replica.domain

import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDateTime
import java.time.ZoneOffset

class TripLogRulesTest {
    private fun ms(day: Int, h: Int, m: Int = 0) =
        LocalDateTime.of(2026, 11, day, h, m).toInstant(ZoneOffset.UTC).toEpochMilli()

    private fun entry(d: Decision, clicked: Boolean?, at: Long = 1_000L) =
        DecisionEntry(at, Offer(3.5, 4), "عبدون", d, clicked, "pkg.a")

    private fun rec(at: Long, price: Double? = 3.5, dest: String? = "عبدون", pickup: Int? = 4, pkg: String = "pkg.a") =
        TripRecord(acceptedAtMs = at, price = price, destination = dest, pickupMinutes = pickup, rule = AcceptRule.NORMAL, sourcePackage = pkg)

    @Test fun acceptedAndClicked_becomesRecord() {
        val r = TripLogRules.toRecord(entry(Decision.Accept(AcceptRule.SHORT_TRIP_OVERRIDE), true))!!
        assertEquals(3.5, r.price!!, 0.0); assertEquals("عبدون", r.destination); assertEquals(4, r.pickupMinutes)
        assertEquals(AcceptRule.SHORT_TRIP_OVERRIDE, r.rule); assertEquals("pkg.a", r.sourcePackage); assertEquals(1_000L, r.acceptedAtMs)
    }

    @Test fun acceptedButClickFailed_isNotHistory() =
        assertNull(TripLogRules.toRecord(entry(Decision.Accept(AcceptRule.NORMAL), false)))

    @Test fun acceptedWithoutClickAttempt_isNotHistory() =
        assertNull(TripLogRules.toRecord(entry(Decision.Accept(AcceptRule.NORMAL), null)))

    @Test fun ignored_isNotHistory() =
        assertNull(TripLogRules.toRecord(entry(Decision.Ignore(IgnoreReason.PRICE_TOO_LOW), null)))

    @Test fun duplicate_sameOfferInsideWindow() = assertTrue(TripLogRules.isDuplicate(rec(0), rec(30_000)))
    @Test fun notDuplicate_afterWindow() = assertFalse(TripLogRules.isDuplicate(rec(0), rec(60_000)))
    @Test fun notDuplicate_differentPrice() = assertFalse(TripLogRules.isDuplicate(rec(0), rec(1_000, price = 4.0)))
    @Test fun notDuplicate_differentDestination() = assertFalse(TripLogRules.isDuplicate(rec(0), rec(1_000, dest = "الجبيهة")))
    @Test fun notDuplicate_differentApp() = assertFalse(TripLogRules.isDuplicate(rec(0), rec(1_000, pkg = "pkg.b")))
    @Test fun notDuplicate_whenNoPreviousTrip() = assertFalse(TripLogRules.isDuplicate(null, rec(0)))

    @Test fun retentionCutoff_is90Days() {
        val day = 86_400_000L
        assertEquals(10 * day, Retention.cutoffMs(100 * day))
    }

    @Test fun groupByDay_keepsNewestFirst() {
        val input = listOf(rec(ms(6, 0, 30)), rec(ms(5, 23)), rec(ms(5, 10)))
        val g = TripLogRules.groupByDay(input, ZoneOffset.UTC)
        assertEquals(2, g.size)
        assertEquals(6, g[0].first.dayOfMonth); assertEquals(1, g[0].second.size)
        assertEquals(5, g[1].first.dayOfMonth); assertEquals(listOf(ms(5, 23), ms(5, 10)), g[1].second.map { it.acceptedAtMs })
    }

    @Test fun groupByDay_emptyList() = assertTrue(TripLogRules.groupByDay(emptyList(), ZoneOffset.UTC).isEmpty())
}
