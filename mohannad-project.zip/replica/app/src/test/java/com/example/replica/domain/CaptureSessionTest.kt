package com.example.replica.domain

import org.junit.Assert.*
import org.junit.Test

class CaptureSessionTest {
    private fun s(max: Int = 30, until: Long = 600_000) = CaptureSession(until, max)

    @Test fun firstTry_isAllowed_secondInsideGap_isNot() {
        val c = s(); assertTrue(c.shouldTry(1_000)); assertFalse(c.shouldTry(1_200)); assertTrue(c.shouldTry(1_500))
    }
    @Test fun newLayout_isAccepted() = assertTrue(s().accept(1_000, 111, false))
    @Test fun sameLayoutTwice_isRejected() { val c = s(); c.accept(1_000, 111, false); assertFalse(c.accept(5_000, 111, false)) }
    @Test fun twoShotsTooClose_secondRejected() { val c = s(); c.accept(1_000, 1, false); assertFalse(c.accept(1_300, 2, false)); assertTrue(c.accept(1_800, 2, false)) }
    @Test fun maxShots_endsTheSession() {
        val c = s(max = 2); c.accept(1_000, 1, false); c.accept(2_000, 2, false)
        assertTrue(c.isOver(2_001)); assertFalse(c.accept(3_000, 3, false)); assertFalse(c.shouldTry(3_000))
    }
    @Test fun timeWindow_expires() { val c = s(until = 10_000); assertFalse(c.isOver(9_999)); assertTrue(c.isOver(10_000)); assertFalse(c.accept(10_000, 1, true)) }
    @Test fun lastSlots_areReservedForOfferLikeScreens() {
        val c = s(max = 6)
        assertTrue(c.accept(1_000, 1, false))            // 6 left: ordinary screen ok
        assertFalse(c.accept(2_000, 2, false))           // 5 left: reserved
        assertTrue(c.accept(3_000, 3, true))             // offer-like still ok
        assertEquals(2, c.shots); assertEquals(1, c.candidates)
    }
    @Test fun appMatch_findsByLabelOrPackage_ignoringCase() {
        val k = AppMatch.DEFAULT_KEYWORDS
        assertTrue(AppMatch.matches("Petra Safeer", "com.x.y", k))
        assertTrue(AppMatch.matches("Driver", "me.JEENY.driver", k))
        assertTrue(AppMatch.matches("بترا سفير", "a.b", k))
        assertFalse(AppMatch.matches("Careem Captain", "com.careem.captain", k))
    }
}
