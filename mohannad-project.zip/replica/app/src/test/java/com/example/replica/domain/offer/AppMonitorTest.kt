package com.example.replica.domain.offer

import org.junit.Assert.assertEquals
import org.junit.Test

class AppMonitorTest {
    private fun st(i: Boolean, e: Boolean, c: Boolean, m: Boolean) = AppStatus.of(i, e, c, m)

    @Test fun notInstalled_winsOverEverything() = assertEquals(AppStatus.NOT_INSTALLED, st(false, true, true, true))
    @Test fun installedButOff() = assertEquals(AppStatus.OFF, st(true, false, true, true))
    @Test fun enabled_butServiceMissing() = assertEquals(AppStatus.NEEDS_SERVICE, st(true, true, false, true))
    @Test fun serviceMissing_beatsMasterOff() = assertEquals(AppStatus.NEEDS_SERVICE, st(true, true, false, false))
    @Test fun enabled_serviceOk_masterOff() = assertEquals(AppStatus.MASTER_OFF, st(true, true, true, false))
    @Test fun enabled_serviceOk_masterOn_isActive() = assertEquals(AppStatus.ACTIVE, st(true, true, true, true))

    @Test fun switchOff_disables() = assertEquals(AppSelection.Disable, AppSelection.decide(false, listOf("a", "b")))
    @Test fun switchOn_nothingInstalled() = assertEquals(AppSelection.NotInstalled, AppSelection.decide(true, emptyList()))
    @Test fun switchOn_oneCandidate_enablesIt() = assertEquals(AppSelection.Enable("a.b"), AppSelection.decide(true, listOf("a.b")))
    @Test fun switchOn_severalCandidates_asksTheUser() =
        assertEquals(AppSelection.Choose(listOf("rider", "driver")), AppSelection.decide(true, listOf("rider", "driver")))
}
