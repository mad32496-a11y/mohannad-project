package com.example.replica.domain

import org.junit.Assert.*
import org.junit.Test

class ScreenDumpTest {
    private fun n(
        text: String? = null, desc: String? = null, clickable: Boolean = false, editable: Boolean = false, password: Boolean = false,
        id: String? = null, cls: String? = "android.widget.TextView", bounds: List<Int> = listOf(0, 0, 10, 10), kids: List<DumpNode> = emptyList(),
    ) = DumpNode(cls, id, text, desc, null, bounds, clickable, true, false, false, editable, password, true, kids)

    // ---- redaction
    @Test fun name_isMasked() = assertEquals("xxxx xxxx", DumpRedactor.redact(n("أحمد محمد")).text)
    @Test fun priceWithCurrency_keepsDigitsAndUnit() = assertEquals("3.5 د.أ", DumpRedactor.redact(n("3.5 د.أ")).text)
    @Test fun minutesWord_isMaskedButNumberKept() = assertEquals("5 xxxxx", DumpRedactor.redact(n("5 دقائق")).text)
    @Test fun addressWithNumber_lettersMasked() = assertEquals("xxxx xxxxxxxx 12", DumpRedactor.redact(n("شارع الوكالات 12")).text)
    @Test fun nameNextToRating_isMasked() = assertEquals("xxx 4.9", DumpRedactor.redact(n("علي 4.9")).text)
    @Test fun asciiUnitNextToNumber_kept() = assertEquals("2 km", DumpRedactor.redact(n("2 km")).text)
    @Test fun clickableLabel_keptWhole() = assertEquals("قبول", DumpRedactor.redact(n("قبول", clickable = true)).text)
    @Test fun editableField_maskedIncludingDigits() = assertEquals("xxxxxxxxxx", DumpRedactor.redact(n("0791234567", editable = true)).text)
    @Test fun passwordField_isDropped() = assertNull(DumpRedactor.redact(n("secret", password = true, editable = true)).text)
    @Test fun contentDesc_isMaskedToo() = assertEquals("xxxx xxxxxx", DumpRedactor.redact(n(desc = "صورة السائق")).contentDesc)
    @Test fun nullText_staysNull() = assertNull(DumpRedactor.redact(n()).text)
    @Test fun redaction_reachesChildren() = assertEquals("xxxx", DumpRedactor.redact(n(kids = listOf(n("سامر")))).children[0].text)
    @Test fun structure_isNotChangedByRedaction() {
        val raw = n("نص", id = "a:id/b", bounds = listOf(1, 2, 3, 4), clickable = true)
        val red = DumpRedactor.redact(raw)
        assertEquals(raw.resourceId, red.resourceId); assertEquals(raw.bounds, red.bounds); assertEquals(raw.clickable, red.clickable)
    }
    @Test fun rawMode_keepsText_butNeverPasswords() {
        val tree = n(kids = listOf(n("أحمد"), n("pw", password = true)))
        val r = DumpRedactor.dropPasswords(tree)
        assertEquals("أحمد", r.children[0].text); assertNull(r.children[1].text)
    }

    // ---- hints
    @Test fun offerLikeScreen_isCandidate() {
        val tree = n(kids = listOf(n("3.5 د.أ"), n("4 دقائق"), n(clickable = true, kids = listOf(n("قبول")))))
        val h = OfferHeuristics.analyze(tree)
        assertTrue(h.acceptLikeButton); assertEquals(2, h.numericNodes); assertTrue(h.isCandidate)
    }
    @Test fun acceptWordOutsideAButton_doesNotCount() =
        assertFalse(OfferHeuristics.analyze(n(kids = listOf(n("قبول الشروط"), n("1"), n("2")))).acceptLikeButton)
    @Test fun screenWithoutNumbers_isNotCandidate() =
        assertFalse(OfferHeuristics.analyze(n(kids = listOf(n("قبول", clickable = true)))).isCandidate)
    @Test fun englishAcceptButton_isDetected() =
        assertTrue(OfferHeuristics.analyze(n(kids = listOf(n("ACCEPT", clickable = true)))).acceptLikeButton)

    // ---- structure hash
    @Test fun hash_ignoresText() = assertEquals(DumpTools.structureHash(n("00:12")), DumpTools.structureHash(n("00:11")))
    @Test fun hash_changesWithBounds() =
        assertNotEquals(DumpTools.structureHash(n(bounds = listOf(0, 0, 10, 10))), DumpTools.structureHash(n(bounds = listOf(0, 0, 10, 20))))
    @Test fun hash_changesWithChildren() = assertNotEquals(DumpTools.structureHash(n()), DumpTools.structureHash(n(kids = listOf(n()))))

    // ---- json
    @Test fun json_escapesAndKeepsShape() {
        val node = DumpNode("android.widget.Button", "x:id/accept", "قبول \"now\"\n", null, null, listOf(1, 2, 3, 4), true, true, false, false, false, false, true)
        val json = DumpJson.write(DumpSnapshot("p.k", 5L, true, mapOf("sdk" to "34"), OfferHints(true, 1, 1), node))
        assertTrue(json.contains("\"text\":\"قبول \\\"now\\\"\\n\""))
        assertTrue(json.contains("\"bounds\":[1,2,3,4]"))
        assertTrue(json.contains("\"package\":\"p.k\""))
        assertTrue(json.contains("\"candidate\":false"))
        assertTrue(json.contains("\"sdk\":\"34\""))
        assertTrue(json.contains("\"desc\":null"))
    }
    @Test fun json_nestsChildren() {
        val json = DumpJson.write(DumpSnapshot("p", 1L, false, emptyMap(), OfferHints(false, 0, 0), n(kids = listOf(n("a"), n("b")))))
        assertEquals(3, Regex("\"class\":").findAll(json).count())
        assertTrue(json.contains("\"redacted\":false"))
    }
}
