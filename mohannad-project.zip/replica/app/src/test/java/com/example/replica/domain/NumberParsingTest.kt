package com.example.replica.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class NumberParsingTest {
    private fun p(s: String?) = NumberParsing.parseDecimal(s)

    @Test fun plain() = assertEquals(3.5, p("3.5")!!, 0.0)
    @Test fun withCurrency() = assertEquals(3.5, p("3.5 د.أ")!!, 0.0)
    @Test fun arabicIndicDigits() = assertEquals(7.0, p("٧")!!, 0.0)
    @Test fun arabicDecimalSeparator() = assertEquals(3.5, p("٣٫٥")!!, 0.0)
    @Test fun commaAsDecimal() = assertEquals(2.5, p("2,5 JD")!!, 0.0)
    @Test fun thousandsAndDecimal() = assertEquals(1250.5, p("1,250.50")!!, 0.0)
    @Test fun thousandsOnly() = assertEquals(1250.0, p("1,250")!!, 0.0)
    @Test fun integerWithWord() = assertEquals(4.0, p("4 دقائق")!!, 0.0)
    @Test fun dash_isNull() = assertNull(p("—"))
    @Test fun blank_isNull() = assertNull(p("  "))
    @Test fun null_isNull() = assertNull(p(null))
}
