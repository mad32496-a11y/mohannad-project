package com.example.replica.domain

import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDateTime
import java.time.ZoneOffset

class BubbleLogicTest {
    private val slop = 8f

    @Test fun shortStillTouch_isTap() = assertEquals(Gesture.TAP, BubbleLogic.classify(1f, 2f, 120, slop))
    @Test fun longStillTouch_isLongPress() = assertEquals(Gesture.LONG_PRESS, BubbleLogic.classify(0f, 0f, 500, slop))
    @Test fun justUnderLongPress_isTap() = assertEquals(Gesture.TAP, BubbleLogic.classify(0f, 0f, 499, slop))
    @Test fun movedBeyondSlop_isDrag() = assertEquals(Gesture.DRAG, BubbleLogic.classify(9f, 0f, 100, slop))
    @Test fun movedExactlySlop_stillTap() = assertEquals(Gesture.TAP, BubbleLogic.classify(8f, 0f, 100, slop))
    @Test fun diagonalMoveCounts() = assertEquals(Gesture.DRAG, BubbleLogic.classify(6f, 6f, 100, slop))   // ~8.49
    @Test fun slowDrag_isStillDrag() = assertEquals(Gesture.DRAG, BubbleLogic.classify(50f, 0f, 2_000, slop))

    @Test fun clamp_insideScreen_unchanged() = assertEquals(100 to 200, BubbleLogic.clamp(100, 200, 1080, 2400, 150))
    @Test fun clamp_negative_goesToZero() = assertEquals(0 to 0, BubbleLogic.clamp(-30, -5, 1080, 2400, 150))
    @Test fun clamp_pastRightBottom_keepsBubbleVisible() = assertEquals(930 to 2250, BubbleLogic.clamp(5000, 5000, 1080, 2400, 150))
    @Test fun clamp_screenSmallerThanBubble_isZero() = assertEquals(0 to 0, BubbleLogic.clamp(10, 10, 100, 100, 150))

    @Test fun snap_leftHalf_goesToLeftMargin() = assertEquals(20, BubbleLogic.snapX(100, 1080, 150, 20))
    @Test fun snap_rightHalf_goesToRightMargin() = assertEquals(1080 - 150 - 20, BubbleLogic.snapX(700, 1080, 150, 20))
    @Test fun defaultPosition_isRightEdge_upperThird() = assertEquals((1080 - 150 - 20) to 800, BubbleLogic.defaultPosition(1080, 2400, 150, 20))

    @Test fun badge_zeroAndNegative_hidden() { assertNull(BubbleLogic.badgeText(0)); assertNull(BubbleLogic.badgeText(-3)) }
    @Test fun badge_normal() = assertEquals("7", BubbleLogic.badgeText(7))
    @Test fun badge_99() = assertEquals("99", BubbleLogic.badgeText(99))
    @Test fun badge_over99() = assertEquals("99+", BubbleLogic.badgeText(100))

    private fun ms(h: Int, m: Int = 0, s: Int = 0) = LocalDateTime.of(2026, 11, 6, h, m, s).toInstant(ZoneOffset.UTC).toEpochMilli()

    @Test fun startOfDay_isMidnightInZone() = assertEquals(ms(0), BubbleLogic.startOfDayMs(ms(15, 30), ZoneOffset.UTC))
    @Test fun msUntilNextDay_oneSecondBeforeMidnight() = assertEquals(1_000L, BubbleLogic.msUntilNextDay(ms(23, 59, 59), ZoneOffset.UTC))
    @Test fun msUntilNextDay_atMidnight_isFullDay() = assertEquals(86_400_000L, BubbleLogic.msUntilNextDay(ms(0), ZoneOffset.UTC))
    @Test fun startOfDay_respectsOffsetZone() {
        val amman = ZoneOffset.ofHours(3)   // fixed offset stand-in for Jordan time
        assertEquals(ms(21) - 86_400_000L, BubbleLogic.startOfDayMs(ms(1), amman))   // 01:00 UTC = 04:00 local; local midnight = 21:00 UTC the day before
    }
}
