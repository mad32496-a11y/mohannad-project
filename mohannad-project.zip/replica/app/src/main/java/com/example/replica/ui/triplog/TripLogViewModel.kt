package com.example.replica.ui.triplog

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.replica.data.TripLogRepository
import com.example.replica.domain.TripRecord
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TripLogViewModel(private val repo: TripLogRepository) : ViewModel() {
    /** null = still loading (avoids flashing the empty state). */
    val trips: StateFlow<List<TripRecord>?> =
        repo.trips.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    init { viewModelScope.launch { repo.prune() } }

    fun clearAll() { viewModelScope.launch { repo.clear() } }
}
