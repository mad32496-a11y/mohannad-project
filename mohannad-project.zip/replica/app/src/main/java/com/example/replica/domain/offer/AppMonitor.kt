package com.example.replica.domain.offer

/** What one ride-app card on Home says, from four facts. Pure and unit-tested. */
enum class AppStatus {
    NOT_INSTALLED, OFF, MASTER_OFF, NEEDS_SERVICE, ACTIVE;

    companion object {
        fun of(installed: Boolean, enabled: Boolean, serviceConnected: Boolean, masterOn: Boolean): AppStatus = when {
            !installed -> NOT_INSTALLED
            !enabled -> OFF
            !serviceConnected -> NEEDS_SERVICE
            !masterOn -> MASTER_OFF
            else -> ACTIVE
        }
    }
}

/** What happens when the user flips a ride app's switch. */
sealed interface AppSelection {
    object Disable : AppSelection
    object NotInstalled : AppSelection
    data class Enable(val packageName: String) : AppSelection
    /** Several installed apps match (for example the rider app and the driver app): the user must pick. */
    data class Choose(val packages: List<String>) : AppSelection

    companion object {
        fun decide(on: Boolean, candidates: List<String>): AppSelection = when {
            !on -> Disable
            candidates.isEmpty() -> NotInstalled
            candidates.size == 1 -> Enable(candidates[0])
            else -> Choose(candidates)
        }
    }
}
