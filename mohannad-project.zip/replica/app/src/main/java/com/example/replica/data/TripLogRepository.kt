package com.example.replica.data

import android.content.Context
import com.example.replica.domain.BubbleLogic
import com.example.replica.domain.Retention
import com.example.replica.domain.TripLogRules
import com.example.replica.domain.TripRecord
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import java.time.ZoneId

class TripLogRepository(
    private val dao: TripLogDao,
    private val now: () -> Long = System::currentTimeMillis,
) {
    val trips: Flow<List<TripRecord>> = dao.observeAll().map { list -> list.map { it.toRecord() } }

    /** false = skipped as a duplicate of the previous trip. */
    suspend fun record(r: TripRecord): Boolean {
        if (TripLogRules.isDuplicate(dao.latest()?.toRecord(), r)) return false
        dao.insert(r.toEntity())
        return true
    }

    /** Trips accepted since local midnight; rolls over by itself at midnight. */
    @OptIn(ExperimentalCoroutinesApi::class)
    fun todayCount(zone: ZoneId = ZoneId.systemDefault()): Flow<Int> = flow {
        while (true) {
            val t = now()
            emit(BubbleLogic.startOfDayMs(t, zone))
            delay(BubbleLogic.msUntilNextDay(t, zone) + 1_000)
        }
    }.flatMapLatest { dao.countSince(it) }

    suspend fun prune(): Int = dao.deleteOlderThan(Retention.cutoffMs(now()))
    suspend fun clear() = dao.deleteAll()

    companion object {
        fun from(context: Context) = TripLogRepository(AppDatabase.get(context).tripLogDao())
    }
}
