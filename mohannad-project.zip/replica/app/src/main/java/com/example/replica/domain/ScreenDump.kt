package com.example.replica.domain

/** One accessibility node, Android-free so dumps can be redacted, hashed and written as JVM-testable pure code. */
data class DumpNode(
    val className: String?, val resourceId: String?, val text: String?, val contentDesc: String?, val hint: String?,
    val bounds: List<Int>,                       // left, top, right, bottom in screen pixels
    val clickable: Boolean, val enabled: Boolean, val checkable: Boolean, val checked: Boolean,
    val editable: Boolean, val password: Boolean, val visible: Boolean,
    val children: List<DumpNode> = emptyList(),
)

data class OfferHints(val acceptLikeButton: Boolean, val numericNodes: Int, val clickableNodes: Int) {
    /** A screen with an accept-like button and at least two numbers (price, minutes) is probably an offer. */
    val isCandidate: Boolean get() = acceptLikeButton && numericNodes >= 2
}

data class DumpSnapshot(
    val pkg: String, val capturedAtMs: Long, val redacted: Boolean,
    val device: Map<String, String>, val hints: OfferHints, val root: DumpNode,
)

object OfferHeuristics {
    private val ACCEPT_WORDS = listOf("قبول", "اقبل", "موافق", "تأكيد", "استلم", "accept", "confirm")

    /** Run on the RAW tree (before redaction), because redaction masks the words we look for on non-buttons. */
    fun analyze(root: DumpNode): OfferHints {
        var accept = false; var numeric = 0; var clickable = 0
        fun walk(n: DumpNode, parentClickable: Boolean) {
            if (n.clickable) clickable++
            val label = listOfNotNull(n.text, n.contentDesc).joinToString(" ")
            if (label.any { it.isDigit() }) numeric++
            if ((n.clickable || parentClickable) && ACCEPT_WORDS.any { label.contains(it, ignoreCase = true) }) accept = true
            n.children.forEach { walk(it, n.clickable || parentClickable) }
        }
        walk(root, false)
        return OfferHints(accept, numeric, clickable)
    }
}

object DumpTools {
    /** Layout fingerprint that ignores text, so a ticking countdown does not look like a new screen. */
    fun structureHash(root: DumpNode): Int {
        var h = 17
        fun walk(n: DumpNode) {
            h = 31 * h + (n.className?.hashCode() ?: 0)
            h = 31 * h + (n.resourceId?.hashCode() ?: 0)
            h = 31 * h + n.bounds.hashCode()
            h = 31 * h + (if (n.clickable) 1 else 0)
            n.children.forEach { walk(it) }
        }
        walk(root)
        return h
    }
}

/**
 * Third parties' data (passenger names, addresses, phone numbers) can appear on a ride-offer screen, so by default
 * letters are masked with 'x' and what is kept is what the parser needs: digits, punctuation, button labels
 * (clickable nodes), and short unit tokens such as "د.أ" or "JD" that sit next to numbers.
 */
object DumpRedactor {
    private val TOKEN = Regex("\\S+")

    fun redact(n: DumpNode): DumpNode =
        n.copy(text = mask(n, n.text), contentDesc = mask(n, n.contentDesc), children = n.children.map { redact(it) })

    /** Raw mode keeps text, but a password field is never kept. */
    fun dropPasswords(n: DumpNode): DumpNode =
        n.copy(text = if (n.password) null else n.text, contentDesc = if (n.password) null else n.contentDesc,
            children = n.children.map { dropPasswords(it) })

    internal fun mask(n: DumpNode, s: String?): String? {
        if (s == null || n.password) return null
        if (n.editable) return s.map { if (it.isWhitespace()) it else 'x' }.joinToString("")   // anything typed: mask digits too
        if (n.clickable) return s                                                                  // button labels stay readable
        val hasDigit = s.any { it.isDigit() }
        return TOKEN.replace(s) { m ->
            val t = m.value
            val isUnit = hasDigit && t.length <= 3 && (t.contains('.') || t.all { it in 'a'..'z' || it in 'A'..'Z' })
            if (isUnit) t else t.map { if (it.isLetter()) 'x' else it }.joinToString("")
        }
    }
}

object DumpJson {
    fun write(s: DumpSnapshot): String {
        val sb = StringBuilder()
        sb.append("{\n")
        sb.append("  \"tool\":\"mohannad-dump-v1\",\n")
        sb.append("  \"package\":").append(str(s.pkg)).append(",\n")
        sb.append("  \"capturedAtMs\":").append(s.capturedAtMs).append(",\n")
        sb.append("  \"redacted\":").append(s.redacted).append(",\n")
        sb.append("  \"device\":{").append(s.device.entries.joinToString(",") { str(it.key) + ":" + str(it.value) }).append("},\n")
        sb.append("  \"hints\":{\"acceptLikeButton\":").append(s.hints.acceptLikeButton)
            .append(",\"numericNodes\":").append(s.hints.numericNodes)
            .append(",\"clickableNodes\":").append(s.hints.clickableNodes)
            .append(",\"candidate\":").append(s.hints.isCandidate).append("},\n")
        sb.append("  \"tree\":\n")
        node(sb, s.root, 2)
        sb.append("\n}\n")
        return sb.toString()
    }

    private fun node(sb: StringBuilder, n: DumpNode, depth: Int) {
        val pad = "  ".repeat(depth)
        sb.append(pad).append("{")
        sb.append("\"class\":").append(str(n.className))
        sb.append(",\"id\":").append(str(n.resourceId))
        sb.append(",\"text\":").append(str(n.text))
        sb.append(",\"desc\":").append(str(n.contentDesc))
        sb.append(",\"hint\":").append(str(n.hint))
        sb.append(",\"bounds\":[").append(n.bounds.joinToString(",")).append("]")
        sb.append(",\"clickable\":").append(n.clickable)
        sb.append(",\"enabled\":").append(n.enabled)
        sb.append(",\"checkable\":").append(n.checkable)
        sb.append(",\"checked\":").append(n.checked)
        sb.append(",\"editable\":").append(n.editable)
        sb.append(",\"password\":").append(n.password)
        sb.append(",\"visible\":").append(n.visible)
        if (n.children.isEmpty()) {
            sb.append(",\"children\":[]}")
        } else {
            sb.append(",\"children\":[\n")
            n.children.forEachIndexed { i, c ->
                node(sb, c, depth + 1)
                if (i < n.children.lastIndex) sb.append(",")
                sb.append("\n")
            }
            sb.append(pad).append("]}")
        }
    }

    private fun str(v: String?): String {
        if (v == null) return "null"
        val sb = StringBuilder("\"")
        for (c in v) when {
            c == '"' -> sb.append("\\\"")
            c == '\\' -> sb.append("\\\\")
            c == '\n' -> sb.append("\\n")
            c == '\r' -> sb.append("\\r")
            c == '\t' -> sb.append("\\t")
            c < ' ' -> sb.append("\\u%04x".format(c.code))
            else -> sb.append(c)
        }
        return sb.append('"').toString()
    }
}
