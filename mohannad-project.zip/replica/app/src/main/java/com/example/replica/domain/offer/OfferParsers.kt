package com.example.replica.domain.offer

import com.example.replica.domain.DumpNode
import com.example.replica.domain.NumberParsing
import com.example.replica.domain.Offer
import kotlin.math.ceil

/**
 * Parsers for the driver apps' offer screens. They work on a DumpNode tree (not on live Android nodes), so they run
 * as plain JVM tests. They were written from SCREENSHOTS, not from real accessibility trees: they match visible words
 * and number formats instead of resource ids, and they must be checked against a real capture before anyone trusts them.
 */
enum class RideApp {
    JEENY, PETRA;

    companion object {
        fun detect(label: String, packageName: String): RideApp? {
            val s = "$label $packageName".lowercase()
            return when {
                listOf("jeeny", "jene", "جيني").any { it in s } -> JEENY
                listOf("petra", "safeer", "بترا", "سفير").any { it in s } -> PETRA
                else -> null
            }
        }
    }
}

/** The button to press: its cleaned label and its on-screen bounds (used to find the live node and as a tap fallback). */
data class AcceptTarget(val label: String, val bounds: List<Int>)

data class ScreenOffer(val offer: Offer, val destination: String?, val accept: AcceptTarget)

interface ScreenOfferParser {
    /** null = this is not an offer screen. */
    fun parse(root: DumpNode): ScreenOffer?
}

object OfferText {
    private val MARKS = Regex("[\u064B-\u065F\u0670\u0640\u200E\u200F\u202A-\u202E]")   // diacritics, tatweel, bidi marks
    private val SPACES = Regex("\\s+")
    private val PRICE_PREFIX = Regex("""(?:JOD|JD)\s*(\d+(?:[.,]\d{1,3})?)""", RegexOption.IGNORE_CASE)                       // JOD 1.50
    private val PRICE_SUFFIX = Regex("""(\d+(?:[.,]\d{1,3})?)\s*(?:د\s*\.?\s*أ|دينار|JOD|JD)""", RegexOption.IGNORE_CASE)    // 1.44 د.أ
    private val PICKUP = Regex("""(\d+(?:[.,]\d+)?)\s*(?:دقيقة|دقائق|دقيقه|min)""", RegexOption.IGNORE_CASE)

    fun clean(s: String): String = SPACES.replace(MARKS.replace(s, ""), " ").trim()

    fun price(label: String): Double? {
        val t = NumberParsing.normalizeDigits(clean(label))
        val m = PRICE_PREFIX.find(t) ?: PRICE_SUFFIX.find(t) ?: return null
        return m.groupValues[1].replace(',', '.').toDoubleOrNull()
    }

    /**
     * Rounded UP to whole minutes: for the whole-number thresholds the rules use, ceil(x) <= N is exactly x <= N,
     * so "2.88 min" is not mistaken for "2 min" by the 1-2 minute rule. Metres and km are not minutes and give null.
     */
    fun pickupMinutes(label: String): Int? {
        val t = NumberParsing.normalizeDigits(clean(label))
        val v = PICKUP.find(t)?.groupValues?.get(1)?.replace(',', '.')?.toDoubleOrNull() ?: return null
        return ceil(v).toInt()
    }
}

internal object OfferScan {
    class Item(val label: String, val node: DumpNode, val clickable: DumpNode?) {
        val top get() = node.bounds.getOrElse(1) { 0 }
        val left get() = node.bounds.getOrElse(0) { 0 }
    }

    /** Visible nodes that carry a label. Text first, then contentDescription (some UI toolkits only fill that one). */
    fun items(root: DumpNode): List<Item> {
        val out = ArrayList<Item>()
        fun walk(n: DumpNode, clickableAncestor: DumpNode?) {
            val anc = if (n.clickable && n.enabled) n else clickableAncestor
            val label = n.text?.takeIf { it.isNotBlank() } ?: n.contentDesc?.takeIf { it.isNotBlank() }
            if (label != null && n.visible) out += Item(label.trim(), n, anc)
            n.children.forEach { walk(it, anc) }
        }
        walk(root, null)
        return out.sortedWith(compareBy({ it.top }, { it.left }))
    }

    /** Only a label that is inside something clickable counts: a plain text "قبول" is not a button. */
    fun findAccept(items: List<Item>, labels: Set<String>): Pair<AcceptTarget, Item>? {
        val item = items.firstOrNull { OfferText.clean(it.label) in labels && it.clickable != null } ?: return null
        return AcceptTarget(OfferText.clean(item.label), item.clickable!!.bounds) to item
    }

    fun firstPrice(items: List<Item>): Pair<Double, Item>? =
        items.firstNotNullOfOrNull { i -> OfferText.price(i.label)?.let { it to i } }

    fun firstPickup(items: List<Item>): Int? = items.firstNotNullOfOrNull { OfferText.pickupMinutes(it.label) }
}

/** Jeeny driver. Offer: type chip, "يبعد N دقائق", fare "JOD 1.50", two addresses, purple "قبول العرض" button. */
class JeenyScreenParser : ScreenOfferParser {
    override fun parse(root: DumpNode): ScreenOffer? {
        val all = OfferScan.items(root)
        val (accept, acceptItem) = OfferScan.findAccept(all, ACCEPT) ?: return null
        val price = OfferScan.firstPrice(all)
        val pickup = OfferScan.firstPickup(all)
        if (price == null && pickup == null) return null            // the word alone is not enough to call it an offer
        val priceTop = price?.second?.top ?: Int.MIN_VALUE
        // the addresses have no labels: the last text between the fare and the button is the drop-off
        val destination = all.filter { it.top > priceTop && it.top < acceptItem.top && !isNoise(it.label) }.lastOrNull()?.label
        return ScreenOffer(Offer(price?.first, pickup), destination, accept)
    }

    private fun isNoise(label: String) =
        OfferText.price(label) != null || OfferText.pickupMinutes(label) != null || label.none { it.isLetter() }

    private companion object { val ACCEPT = setOf("قبول العرض") }
}

/** Petra driver. Offer: type chip, fare "1.44 د.أ", "2.88 دقيقة • 830 متر", labelled start/end, orange "قبول", small red "رفض". */
class PetraScreenParser : ScreenOfferParser {
    override fun parse(root: DumpNode): ScreenOffer? {
        val all = OfferScan.items(root)
        val (accept, acceptItem) = OfferScan.findAccept(all, ACCEPT) ?: return null   // exact "قبول": never "رفض" (reject)
        val price = OfferScan.firstPrice(all)
        val pickup = OfferScan.firstPickup(all)
        if (price == null && pickup == null) return null
        val i = all.indexOfFirst { OfferText.clean(it.label).startsWith(DEST_LABEL) }
        val destination = if (i < 0) null else {
            val rest = OfferText.clean(all[i].label).removePrefix(DEST_LABEL).trim()       // label and value merged in one node
            rest.ifEmpty { all.getOrNull(i + 1)?.takeIf { it.top < acceptItem.top }?.label }   // or the next text down
        }
        return ScreenOffer(Offer(price?.first, pickup), destination, accept)
    }

    private companion object { val ACCEPT = setOf("قبول"); const val DEST_LABEL = "نقطة الوصول" }
}
