package com.example.replica.ui.simulator

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.testTagsAsResourceId
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.replica.domain.Decision
import com.example.replica.domain.DecisionEntry
import com.example.replica.service.ServiceState
import com.example.replica.ui.theme.Tok
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class SimOffer(val price: String, val pickup: String, val destination: String)

/**
 * Fake "ride app" offer popup, for testing AcceptService without any real app (dev tool, not a product feature).
 * Tags sim_price / sim_pickup / sim_destination / sim_accept are what SimulatorOfferParser reads.
 */
@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun SimulatorScreen(onOpenAccessibility: () -> Unit) {
    val connected by ServiceState.connected.collectAsState()
    val decisions by ServiceState.decisions.collectAsState()
    var price by remember { mutableStateOf("3.5") }
    var pickup by remember { mutableStateOf("4") }
    var destination by remember { mutableStateOf("عبدون") }
    var offer by remember { mutableStateOf<SimOffer?>(null) }
    var lastAction by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().background(Tok.bgPage).semantics { testTagsAsResourceId = true }
            .verticalScroll(rememberScrollState()).statusBarsPadding().navigationBarsPadding().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("محاكي العروض (للاختبار فقط)", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(if (connected) "خدمة القبول: متصلة" else "خدمة القبول: غير متصلة", color = if (connected) Tok.successText else Tok.textSecondary)
        if (!connected) OutlinedButton(onOpenAccessibility) { Text("فعّل الخدمة من إعدادات إمكانية الوصول") }
        Text("شغّل القبول التلقائي من الشاشة الرئيسية، ثم اعرض طلباً هنا.", fontSize = 12.sp, color = Tok.textSecondary)

        OutlinedTextField(price, { price = it }, Modifier.fillMaxWidth(), label = { Text("السعر (فارغ = بدون سعر)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
        OutlinedTextField(pickup, { pickup = it }, Modifier.fillMaxWidth(), label = { Text("وقت الوصول بالدقائق") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
        OutlinedTextField(destination, { destination = it }, Modifier.fillMaxWidth(), label = { Text("الوجهة") }, singleLine = true)
        Button({ offer = SimOffer(price.trim(), pickup.trim(), destination.trim()); lastAction = "" }, Modifier.fillMaxWidth()) { Text("اعرض الطلب") }

        offer?.let { o ->
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Tok.surface).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(if (o.price.isBlank()) "—" else "${o.price} د.أ", Modifier.testTag("sim_price"), fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text(if (o.pickup.isBlank()) "—" else "${o.pickup} دقائق", Modifier.testTag("sim_pickup"))
                Text(o.destination.ifBlank { "—" }, Modifier.testTag("sim_destination"))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button({ offer = null; lastAction = "تم الضغط على قبول" }, Modifier.weight(1f).testTag("sim_accept")) { Text("قبول") }
                    OutlinedButton({ offer = null; lastAction = "تم الرفض" }, Modifier.weight(1f).testTag("sim_reject")) { Text("رفض") }
                }
            }
        }
        if (lastAction.isNotEmpty()) Text(lastAction, color = Tok.primaryContent, fontWeight = FontWeight.Medium)

        CaptureSection()

        Spacer(Modifier.height(8.dp))
        Text("آخر القرارات", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        if (decisions.isEmpty()) Text("لا شيء بعد", color = Tok.textSecondary)
        decisions.forEach { Text(describe(it), fontSize = 12.sp) }
    }
}

private fun describe(e: DecisionEntry): String {
    val time = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(e.atMs))
    val d = when (val x = e.decision) { is Decision.Accept -> "قبول ${x.rule}"; is Decision.Ignore -> "تجاهل ${x.reason}" }
    val click = when (e.clicked) { true -> " ✓"; false -> " ✗ فشل الضغط"; null -> "" }
    return "$time · $d$click · سعر=${e.offer.price ?: "—"} · وصول=${e.offer.pickupMinutes ?: "—"}"
}
