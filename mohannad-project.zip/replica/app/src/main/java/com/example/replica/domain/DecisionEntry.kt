package com.example.replica.domain

/** One line of the decision log: what was seen, what the engine decided, and whether the click worked. */
data class DecisionEntry(
    val atMs: Long,
    val offer: Offer,
    val destination: String?,
    val decision: Decision,
    val clicked: Boolean?,   // null = no click attempted
    val sourcePackage: String = "",
)
