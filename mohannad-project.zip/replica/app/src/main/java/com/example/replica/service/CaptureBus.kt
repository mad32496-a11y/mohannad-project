package com.example.replica.service

import kotlinx.coroutines.flow.MutableStateFlow

/** Same-process channel between the dev screen (asks for a capture) and AcceptService (does it). */
data class CaptureRequest(
    val packages: Set<String>, val durationMs: Long, val maxShots: Int, val keepRaw: Boolean,
    val id: Long,   // a fresh id makes re-arming with identical settings count as a new request
)

data class CaptureStatus(
    val armed: Boolean = false, val untilMs: Long = 0, val shots: Int = 0, val maxShots: Int = 0,
    val candidates: Int = 0, val message: String = "",
)

object CaptureBus {
    val request = MutableStateFlow<CaptureRequest?>(null)
    val status = MutableStateFlow(CaptureStatus())
}
