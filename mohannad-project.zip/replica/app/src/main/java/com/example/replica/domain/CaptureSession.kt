package com.example.replica.domain

/**
 * Decides which screens are worth saving while capture is armed. We do not know what an offer looks like yet,
 * so it saves every new layout (up to a limit), and keeps the last few slots for screens that look like offers.
 */
class CaptureSession(val armedUntilMs: Long, val maxShots: Int) {
    var shots = 0; private set
    var candidates = 0; private set
    private var lastTryAt = -1_000_000L
    private var lastShotAt = -1_000_000L
    private val seen = mutableSetOf<Int>()

    fun isOver(nowMs: Long) = nowMs >= armedUntilMs || shots >= maxShots

    /** Cheap gate before any tree is built, so a busy app cannot make us burn CPU on every event. */
    fun shouldTry(nowMs: Long): Boolean {
        if (isOver(nowMs) || nowMs - lastTryAt < TRY_GAP_MS) return false
        lastTryAt = nowMs
        return true
    }

    fun accept(nowMs: Long, structureHash: Int, candidate: Boolean): Boolean {
        if (isOver(nowMs)) return false
        if (nowMs - lastShotAt < SHOT_GAP_MS) return false
        if (structureHash in seen) return false
        if (maxShots - shots <= RESERVE && !candidate) return false
        seen += structureHash; lastShotAt = nowMs; shots++
        if (candidate) candidates++
        return true
    }

    companion object {
        const val TRY_GAP_MS = 400L
        const val SHOT_GAP_MS = 700L
        const val RESERVE = 5
    }
}

object AppMatch {
    val DEFAULT_KEYWORDS = listOf("petra", "safeer", "jeeny", "jene", "بترا", "سفير", "جيني")
    /** Rider apps (not driver apps) that match the keywords. Confirmed from a public listing, not guessed. */
    val KNOWN_RIDER_PACKAGES = setOf("com.PetraRide_User")
    fun matches(label: String, packageName: String, keywords: List<String>): Boolean =
        keywords.any { label.contains(it, ignoreCase = true) || packageName.contains(it, ignoreCase = true) }
}
