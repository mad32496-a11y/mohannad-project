package com.example.replica.domain

/**
 * Pure function: offer + settings in, decision out. No Android imports, so it runs as a plain JVM unit test.
 *
 * Rules (recon + user-confirmed):
 *  - Short-trip override: pickup of 0..2 minutes is accepted even if the min-price rule fails.
 *  - Price-overrides-time: if price >= override value, the max-pickup rule is skipped (min price still applies).
 *  - Offers with no price are accepted only when "accept without destination" is on, and then only the time rule applies.
 * Assumptions to confirm on a real device: the price-less offer == "no destination" offer, and the
 * price-overrides-time rule does not bypass the min-price rule.
 */
object DecisionEngine {
    const val SHORT_TRIP_MAX_MINUTES = 2

    private enum class Time { OK, FAR, UNKNOWN }

    fun evaluate(offer: Offer, s: Settings, entitled: Boolean = true): Decision {
        if (!entitled) return Decision.Ignore(IgnoreReason.NOT_ENTITLED)
        if (!s.autoAcceptEnabled) return Decision.Ignore(IgnoreReason.AUTO_ACCEPT_OFF)

        val price = offer.price
        val pickup = offer.pickupMinutes
        if ((price != null && (price.isNaN() || price < 0.0)) || (pickup != null && pickup < 0)) {
            return Decision.Ignore(IgnoreReason.INVALID_OFFER)
        }

        val time = timeCheck(pickup, s)

        // Offers without a price
        if (price == null) {
            if (!s.acceptNoDestinationEnabled) return Decision.Ignore(IgnoreReason.NO_PRICE_NOT_ALLOWED)
            return when (time) {
                Time.OK -> Decision.Accept(AcceptRule.NO_DESTINATION_TIME_ONLY)
                Time.FAR -> Decision.Ignore(IgnoreReason.PICKUP_TOO_FAR)
                Time.UNKNOWN -> Decision.Ignore(IgnoreReason.PICKUP_UNKNOWN)
            }
        }

        // Min-price rule, with the short-trip override
        val priceOk = !s.minPriceEnabled || price >= s.minPrice
        if (!priceOk) {
            val shortTrip = s.shortTripOverrideEnabled && pickup != null && pickup <= SHORT_TRIP_MAX_MINUTES
            return if (shortTrip) Decision.Accept(AcceptRule.SHORT_TRIP_OVERRIDE)
            else Decision.Ignore(IgnoreReason.PRICE_TOO_LOW)
        }

        // Max-pickup rule, with the price-overrides-time exception
        if (time == Time.OK) return Decision.Accept(AcceptRule.NORMAL)
        if (s.priceOverrideTimeEnabled && price >= s.priceOverrideTimeValue) {
            return Decision.Accept(AcceptRule.PRICE_OVERRIDES_TIME)
        }
        return Decision.Ignore(if (time == Time.UNKNOWN) IgnoreReason.PICKUP_UNKNOWN else IgnoreReason.PICKUP_TOO_FAR)
    }

    private fun timeCheck(pickup: Int?, s: Settings): Time = when {
        !s.maxPickupEnabled -> Time.OK
        pickup == null -> Time.UNKNOWN
        pickup <= s.maxPickupMinutes -> Time.OK
        else -> Time.FAR
    }
}
