package com.example.replica.service

import com.example.replica.domain.Decision
import com.example.replica.domain.DecisionEngine
import com.example.replica.domain.DecisionEntry
import com.example.replica.domain.Settings

/**
 * parsed offer -> engine -> click -> log. Pure Kotlin (clock and settings are injected).
 * Accessibility events fire many times for one offer, and our own click fires more, so identical
 * offers inside [dedupWindowMs] are handled once. A failed click clears the key so the next event retries.
 */
class OfferPipeline(
    private val settings: () -> Settings,
    private val entitled: () -> Boolean,
    private val now: () -> Long = System::currentTimeMillis,
    private val dedupWindowMs: Long = 3_000,
    private val onDecision: (DecisionEntry) -> Unit,
) {
    private var lastKey: String? = null
    private var lastAt = 0L

    fun handle(p: ParsedOffer) {
        val t = now()
        val key = "${p.offer.price}|${p.offer.pickupMinutes}|${p.destination}"
        if (key == lastKey && t - lastAt < dedupWindowMs) return
        lastKey = key; lastAt = t

        val decision = DecisionEngine.evaluate(p.offer, settings(), entitled())
        var clicked: Boolean? = null
        if (decision is Decision.Accept) {
            clicked = p.accept()
            if (clicked == false) lastKey = null
        }
        onDecision(DecisionEntry(t, p.offer, p.destination, decision, clicked, p.sourcePackage))
    }
}
