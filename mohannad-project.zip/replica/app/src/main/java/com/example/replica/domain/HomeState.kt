package com.example.replica.domain

/** What the big card on Home should show. Pure, so "why is it not running?" is unit-tested. */
enum class HeroState {
    STOPPED, RUNNING, NEEDS_ACCESSIBILITY, NEEDS_APP;

    companion object {
        /** The master switch can be on while nothing happens (no service, or no ride app switched on). The card must say so. */
        fun from(autoOn: Boolean, serviceConnected: Boolean, anyAppEnabled: Boolean): HeroState = when {
            !autoOn -> STOPPED
            !serviceConnected -> NEEDS_ACCESSIBILITY
            !anyAppEnabled -> NEEDS_APP
            else -> RUNNING
        }
    }
}

enum class HeroAction { TURN_ON, TURN_OFF, OPEN_ACCESSIBILITY }

val HeroState.primaryAction: HeroAction
    get() = when (this) {
        HeroState.STOPPED -> HeroAction.TURN_ON
        HeroState.RUNNING -> HeroAction.TURN_OFF
        HeroState.NEEDS_ACCESSIBILITY -> HeroAction.OPEN_ACCESSIBILITY
        HeroState.NEEDS_APP -> HeroAction.TURN_OFF
    }

enum class DrawerDestination { HOME, TRIP_LOG, SIMULATOR }

object DrawerDestinations {
    /** The simulator is a developer tool, so it only shows in debuggable builds. */
    fun visible(devTools: Boolean): List<DrawerDestination> =
        DrawerDestination.values().filter { it != DrawerDestination.SIMULATOR || devTools }
}
