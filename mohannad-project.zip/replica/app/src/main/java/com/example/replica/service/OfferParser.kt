package com.example.replica.service

import android.view.accessibility.AccessibilityNodeInfo
import com.example.replica.domain.NumberParsing
import com.example.replica.domain.Offer

/** One adapter per supported ride app. This is the only code that knows another app's screen. */
interface OfferParser {
    fun supports(packageName: String): Boolean
    /** null = no offer on screen. */
    fun parse(root: AccessibilityNodeInfo): ParsedOffer?
}

object NodeFinder {
    /** Manual tree walk: findAccessibilityNodeInfosByViewId is unreliable on Compose trees. */
    fun byViewId(node: AccessibilityNodeInfo?, id: String): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.viewIdResourceName?.substringAfterLast('/') == id) return node
        for (i in 0 until node.childCount) {
            byViewId(node.getChild(i), id)?.let { return it }
        }
        return null
    }

    fun click(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        while (n != null && !n.isClickable) n = n.parent
        return n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
    }
}

/** Reads the in-app Offer Simulator (tags sim_price, sim_pickup, sim_destination, sim_accept). */
class SimulatorOfferParser(private val ownPackage: String) : OfferParser {
    override fun supports(packageName: String) = packageName == ownPackage

    override fun parse(root: AccessibilityNodeInfo): ParsedOffer? {
        val acceptNode = NodeFinder.byViewId(root, "sim_accept") ?: return null   // no offer card showing
        val price = NumberParsing.parseDecimal(NodeFinder.byViewId(root, "sim_price")?.text?.toString())
        val pickup = NumberParsing.parseDecimal(NodeFinder.byViewId(root, "sim_pickup")?.text?.toString())?.toInt()
        val destination = NodeFinder.byViewId(root, "sim_destination")?.text?.toString()?.takeIf { it.isNotBlank() && it != "—" }
        return ParsedOffer(Offer(price, pickup), destination, ownPackage) { NodeFinder.click(acceptNode) }
    }
}
