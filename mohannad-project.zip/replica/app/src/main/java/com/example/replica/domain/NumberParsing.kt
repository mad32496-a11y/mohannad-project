package com.example.replica.domain

/** Turns on-screen text such as "3.5 JD", "٣٫٥" or "1,250.50" into a number. Pure Kotlin. */
object NumberParsing {
    private val NUMBER = Regex("""\d+(\.\d+)?""")

    /** Arabic-Indic digits and separators to ASCII, nothing else touched. */
    fun normalizeDigits(raw: String): String {
        val sb = StringBuilder(raw.length)
        for (ch in raw) {
            sb.append(
                when (ch) {
                    in '\u0660'..'\u0669' -> '0' + (ch - '\u0660')   // Arabic-Indic digits
                    in '\u06F0'..'\u06F9' -> '0' + (ch - '\u06F0')   // Eastern Arabic-Indic digits
                    '\u066B' -> '.'                                    // Arabic decimal separator
                    '\u066C' -> ','                                    // Arabic thousands separator
                    else -> ch
                }
            )
        }
        return sb.toString()
    }

    fun parseDecimal(raw: String?): Double? {
        if (raw.isNullOrBlank()) return null
        var s = normalizeDigits(raw)
        s = when {
            '.' in s && ',' in s -> s.replace(",", "")                           // 1,250.50
            ',' in s && Regex("""\d,\d{3}(\D|$)""").containsMatchIn(s) -> s.replace(",", "")   // 1,250
            ',' in s -> s.replace(',', '.')                                      // 2,5
            else -> s
        }
        return NUMBER.find(s)?.value?.toDoubleOrNull()
    }
}
