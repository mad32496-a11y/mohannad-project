package com.example.replica.domain

import java.time.Instant
import java.time.ZoneId
import kotlin.math.max
import kotlin.math.sqrt

enum class Gesture { TAP, LONG_PRESS, DRAG }

/** Pure geometry and gesture rules for the floating bubble, so they run as JVM unit tests. */
object BubbleLogic {
    const val SIZE_DP = 56
    const val EDGE_MARGIN_DP = 8
    const val LONG_PRESS_MS = 500L

    fun classify(dx: Float, dy: Float, durationMs: Long, slopPx: Float, longPressMs: Long = LONG_PRESS_MS): Gesture {
        val moved = sqrt(dx * dx + dy * dy)
        return when {
            moved > slopPx -> Gesture.DRAG
            durationMs >= longPressMs -> Gesture.LONG_PRESS
            else -> Gesture.TAP
        }
    }

    /** Keeps the whole bubble on screen. */
    fun clamp(x: Int, y: Int, screenW: Int, screenH: Int, size: Int): Pair<Int, Int> =
        x.coerceIn(0, max(0, screenW - size)) to y.coerceIn(0, max(0, screenH - size))

    /** After a drag, glue the bubble to the nearer vertical edge. */
    fun snapX(x: Int, screenW: Int, size: Int, margin: Int): Int =
        if (x + size / 2 < screenW / 2) margin else max(margin, screenW - size - margin)

    fun defaultPosition(screenW: Int, screenH: Int, size: Int, margin: Int): Pair<Int, Int> =
        max(margin, screenW - size - margin) to screenH / 3

    /** null = no badge. */
    fun badgeText(count: Int): String? = when {
        count <= 0 -> null
        count > 99 -> "99+"
        else -> count.toString()
    }

    fun startOfDayMs(nowMs: Long, zone: ZoneId): Long =
        Instant.ofEpochMilli(nowMs).atZone(zone).toLocalDate().atStartOfDay(zone).toInstant().toEpochMilli()

    fun msUntilNextDay(nowMs: Long, zone: ZoneId): Long =
        Instant.ofEpochMilli(nowMs).atZone(zone).toLocalDate().plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli() - nowMs
}
