package com.example.replica.data

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Where capture files live: <external files dir>/dumps, which on a phone is
 * /sdcard/Android/data/<package>/files/dumps/ (app-private, no storage permission). Pull it with
 *   adb pull /sdcard/Android/data/com.example.replica/files/dumps
 * or use the in-app "share all (zip)" button, which works without a computer.
 */
class DumpStore(private val ctx: Context) {
    private val dir: File get() = (ctx.getExternalFilesDir("dumps") ?: File(ctx.filesDir, "dumps")).also { it.mkdirs() }
    val dirPath: String get() = dir.absolutePath

    fun write(name: String, json: String): File = File(dir, name).also { it.writeText(json) }

    fun list(): List<File> =
        dir.listFiles { f -> f.extension == "json" }?.sortedByDescending { it.lastModified() } ?: emptyList()

    fun clear() { dir.listFiles()?.forEach { it.delete() } }

    /** One zip so the user shares a single file (WhatsApp, Drive, e-mail). Null when there is nothing to share. */
    fun zipAll(): File? {
        val files = list()
        if (files.isEmpty()) return null
        val out = File(dir, ZIP_NAME)
        ZipOutputStream(out.outputStream().buffered()).use { z ->
            files.forEach { f ->
                z.putNextEntry(ZipEntry(f.name))
                f.inputStream().use { it.copyTo(z) }
                z.closeEntry()
            }
        }
        return out
    }

    fun shareIntent(file: File): Intent {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
        return Intent(Intent.ACTION_SEND).setType("application/zip")
            .putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }

    private companion object { const val ZIP_NAME = "mohannad-dumps.zip" }
}
