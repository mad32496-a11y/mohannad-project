package com.example.replica.ui.simulator

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.replica.data.DumpStore
import com.example.replica.domain.AppMatch
import com.example.replica.service.CaptureBus
import com.example.replica.service.CaptureRequest
import com.example.replica.service.LaunchableApps
import com.example.replica.service.ServiceState
import com.example.replica.ui.theme.Tok

/** Dev tool (debug builds, inside the Offer Simulator screen): arm a capture, open the driver app, wait for an offer. */
@Composable
fun CaptureSection() {
    val ctx = LocalContext.current
    val store = remember { DumpStore(ctx) }
    val status by CaptureBus.status.collectAsState()
    val connected by ServiceState.connected.collectAsState()
    val apps = remember {
        LaunchableApps.find(ctx.packageManager, AppMatch.DEFAULT_KEYWORDS)
            .filter { it.packageName != ctx.packageName && it.packageName !in AppMatch.KNOWN_RIDER_PACKAGES }
    }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var manual by remember { mutableStateOf("") }
    var keepRaw by remember { mutableStateOf(false) }
    var files by remember { mutableStateOf(store.list()) }
    LaunchedEffect(status.shots, status.armed) { files = store.list() }
    val targets = selected + setOfNotNull(manual.trim().ifEmpty { null })

    Spacer(Modifier.height(8.dp))
    Text("التقاط شجرة الشاشة (للتطوير)", fontSize = 16.sp, fontWeight = FontWeight.Bold)
    Text("اختر تطبيق السائق، اضغط «التقط الشاشة التالية»، افتح التطبيق وانتظر وصول عروض. يتوقف الالتقاط بعد 10 دقائق أو 30 لقطة.",
        fontSize = 12.sp, color = Tok.textSecondary)
    if (!connected) Text("فعّل خدمة إمكانية الوصول أولاً.", fontSize = 12.sp, color = Tok.textSecondary)

    if (apps.isEmpty()) Text("ما لقيت تطبيقات بترا أو جيني مثبتة. ثبّت تطبيق السائق، أو اكتب الحزمة يدوياً.", fontSize = 12.sp)
    apps.forEach { a ->
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(a.packageName in selected, { on -> selected = if (on) selected + a.packageName else selected - a.packageName })
            Column { Text(a.label, fontSize = 14.sp); Text(a.packageName, fontSize = 11.sp, color = Tok.textSecondary) }
        }
    }
    OutlinedTextField(manual, { manual = it }, Modifier.fillMaxWidth(), label = { Text("حزمة يدوية (اختياري)") }, singleLine = true)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(keepRaw, { keepRaw = it })
        Text("حفظ النسخة الخام (تحتوي أسماء وعناوين الركاب. الافتراضي: مخفية)", fontSize = 12.sp)
    }

    Button(
        { CaptureBus.request.value = CaptureRequest(targets, 10 * 60_000L, 30, keepRaw, System.currentTimeMillis()) },
        Modifier.fillMaxWidth(), enabled = connected && targets.isNotEmpty() && !status.armed,
    ) { Text("التقط الشاشة التالية") }

    if (status.armed) {
        Text("الالتقاط مفعّل: ${status.shots}/${status.maxShots} لقطة · عروض محتملة: ${status.candidates}. افتح تطبيق السائق الآن.", fontSize = 12.sp, color = Tok.successText)
        OutlinedButton({ CaptureBus.request.value = null }, Modifier.fillMaxWidth()) { Text("إيقاف الالتقاط") }
    } else if (status.message.isNotEmpty()) {
        Text("${status.message} · اللقطات: ${status.shots} · عروض محتملة: ${status.candidates}", fontSize = 12.sp)
    }

    files.take(8).forEach { Text(it.name + if (it.name.contains("_offer")) "  ← عرض محتمل" else "", fontSize = 11.sp) }
    if (files.size > 8) Text("… و${files.size - 8} ملفات أخرى", fontSize = 11.sp, color = Tok.textSecondary)

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        OutlinedButton({
            store.zipAll()?.let { ctx.startActivity(Intent.createChooser(store.shareIntent(it), "مشاركة اللقطات")) }
        }, Modifier.weight(1f), enabled = files.isNotEmpty()) { Text("مشاركة الكل (zip)") }
        OutlinedButton({ store.clear(); files = store.list() }, Modifier.weight(1f), enabled = files.isNotEmpty()) { Text("مسح الكل") }
    }
    Text("المسار: ${store.dirPath}", fontSize = 11.sp, color = Tok.textSecondary)
    Text("من الكمبيوتر: adb pull ${store.dirPath}", fontSize = 11.sp, color = Tok.textSecondary)
}
