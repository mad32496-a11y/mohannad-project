package com.example.replica.service

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import com.example.replica.R
import com.example.replica.domain.BubbleLogic
import com.example.replica.domain.Gesture
import kotlin.math.roundToInt

/**
 * Floating bubble drawn as an accessibility overlay owned by AcceptService. Because it uses
 * TYPE_ACCESSIBILITY_OVERLAY it needs no "draw over other apps" permission and no foreground service,
 * but it exists only while the accessibility service is connected.
 *  - tap: toggle auto-accept   - long press: open the app   - drag: move (snaps to the nearer edge)
 *  - badge: trips accepted today   - pulse: a trip was just accepted
 */
class BubbleController(
    service: AccessibilityService,
    private val onToggle: () -> Unit,
    private val onLongPress: () -> Unit,
) {
    private val ctx: Context = service
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val prefs = ctx.getSharedPreferences("bubble", Context.MODE_PRIVATE)
    private val density = ctx.resources.displayMetrics.density
    private val sizePx = (BubbleLogic.SIZE_DP * density).roundToInt()
    private val marginPx = (BubbleLogic.EDGE_MARGIN_DP * density).roundToInt()
    private val slopPx = ViewConfiguration.get(ctx).scaledTouchSlop.toFloat()

    private var root: FrameLayout? = null
    private var circle: GradientDrawable? = null
    private var icon: ImageView? = null
    private var badge: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private var autoOn = false
    private var badgeCount = 0

    fun render(visible: Boolean, autoAcceptOn: Boolean) {
        autoOn = autoAcceptOn
        if (visible) { show(); applyState() } else hide()
    }

    fun setBadge(count: Int) { badgeCount = count; applyState() }

    fun pulse() {
        val r = root ?: return
        r.animate().scaleX(1.25f).scaleY(1.25f).setDuration(150)
            .withEndAction { r.animate().scaleX(1f).scaleY(1f).setDuration(150).start() }.start()
    }

    fun hide() {
        root?.let { runCatching { wm.removeView(it) } }
        root = null; circle = null; icon = null; badge = null; params = null
    }

    fun onScreenChanged() {
        val p = params ?: return
        val (w, h) = screen()
        val (x, y) = BubbleLogic.clamp(p.x, p.y, w, h, sizePx)
        p.x = x; p.y = y; update()
    }

    // ---- internals
    private fun screen() = ctx.resources.displayMetrics.let { it.widthPixels to it.heightPixels }
    private fun dp(v: Int) = (v * density).roundToInt()
    private fun update() { runCatching { wm.updateViewLayout(root, params) } }

    private fun show() {
        if (root != null) return
        val (sw, sh) = screen()
        val saved = if (prefs.contains(KEY_X)) prefs.getInt(KEY_X, 0) to prefs.getInt(KEY_Y, 0)
        else BubbleLogic.defaultPosition(sw, sh, sizePx, marginPx)
        val (px, py) = BubbleLogic.clamp(saved.first, saved.second, sw, sh, sizePx)

        val bg = GradientDrawable().apply { shape = GradientDrawable.OVAL; setStroke(dp(2), Color.WHITE) }
        val iv = ImageView(ctx).apply {
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(14), dp(14), dp(14), dp(14))
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        val bd = TextView(ctx).apply {
            textSize = 10f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            minWidth = dp(18); minHeight = dp(18); setPadding(dp(4), 0, dp(4), 0)
            background = GradientDrawable().apply { shape = GradientDrawable.RECTANGLE; cornerRadius = dp(9).toFloat(); setColor(BADGE) }
            visibility = View.GONE
        }
        val frame = FrameLayout(ctx).apply {
            background = bg
            addView(iv, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            addView(bd, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.RIGHT))
            isClickable = true
            setOnClickListener { onToggle() }
            setOnLongClickListener { onLongPress(); true }
        }
        val lp = WindowManager.LayoutParams(
            sizePx, sizePx, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.TOP or Gravity.LEFT; this.x = px; this.y = py }   // LEFT, not START: x is always from the left edge

        params = lp
        attachTouch(frame)
        if (runCatching { wm.addView(frame, lp) }.isSuccess) { root = frame; circle = bg; icon = iv; badge = bd }
    }

    private fun applyState() {
        val r = root ?: return
        circle?.setColor(if (autoOn) ON else OFF)
        icon?.setImageResource(if (autoOn) R.drawable.ic_bubble_on else R.drawable.ic_bubble_off)
        val text = BubbleLogic.badgeText(badgeCount)
        badge?.let { it.text = text; it.visibility = if (text == null) View.GONE else View.VISIBLE }
        r.contentDescription = ctx.getString(if (autoOn) R.string.bubble_on else R.string.bubble_off) + (text?.let { " · $it" } ?: "")
    }

    private fun attachTouch(v: View) {
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var dragging = false
        v.setOnTouchListener { view, e ->
            val p = params ?: return@setOnTouchListener false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startX = p.x; startY = p.y; dragging = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (!dragging && BubbleLogic.classify(dx, dy, 0, slopPx) == Gesture.DRAG) dragging = true
                    if (dragging) {
                        val (sw, sh) = screen()
                        val (x, y) = BubbleLogic.clamp(startX + dx.roundToInt(), startY + dy.roundToInt(), sw, sh, sizePx)
                        p.x = x; p.y = y; update()
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    when (BubbleLogic.classify(e.rawX - downX, e.rawY - downY, e.eventTime - e.downTime, slopPx)) {
                        Gesture.TAP -> view.performClick()
                        Gesture.LONG_PRESS -> view.performLongClick()
                        Gesture.DRAG -> {
                            p.x = BubbleLogic.snapX(p.x, screen().first, sizePx, marginPx); update()
                            prefs.edit().putInt(KEY_X, p.x).putInt(KEY_Y, p.y).apply()
                        }
                    }
                    true
                }
                else -> true
            }
        }
    }

    private companion object {
        const val KEY_X = "x"; const val KEY_Y = "y"
        // from replica/design/tokens.json (color_clone): success.track, switch.off.outline, primary
        val ON = Color.parseColor("#2E7D46"); val OFF = Color.parseColor("#7A767E"); val BADGE = Color.parseColor("#674ECE")
    }
}
