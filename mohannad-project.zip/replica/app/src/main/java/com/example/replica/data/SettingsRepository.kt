package com.example.replica.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.example.replica.domain.Settings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsStore by preferencesDataStore(name = "settings")

class SettingsRepository(private val context: Context) {
    private object K {
        val auto = booleanPreferencesKey("auto_accept_enabled")
        val minOn = booleanPreferencesKey("min_price_enabled"); val min = doublePreferencesKey("min_price")
        val maxOn = booleanPreferencesKey("max_pickup_enabled"); val max = intPreferencesKey("max_pickup_minutes")
        val ovOn = booleanPreferencesKey("price_override_time_enabled"); val ov = doublePreferencesKey("price_override_time_value")
        val shortOn = booleanPreferencesKey("short_trip_override_enabled")
        val noDest = booleanPreferencesKey("accept_no_destination_enabled")
        val bubble = booleanPreferencesKey("bubble_visible")
    }

    val settings: Flow<Settings> = context.settingsStore.data.map { it.toSettings() }

    suspend fun update(transform: (Settings) -> Settings) {
        context.settingsStore.edit { p ->
            val n = transform(p.toSettings())
            p[K.auto] = n.autoAcceptEnabled
            p[K.minOn] = n.minPriceEnabled; p[K.min] = n.minPrice
            p[K.maxOn] = n.maxPickupEnabled; p[K.max] = n.maxPickupMinutes
            p[K.ovOn] = n.priceOverrideTimeEnabled; p[K.ov] = n.priceOverrideTimeValue
            p[K.shortOn] = n.shortTripOverrideEnabled
            p[K.noDest] = n.acceptNoDestinationEnabled
            p[K.bubble] = n.bubbleVisible
        }
    }

    private fun Preferences.toSettings(): Settings {
        val d = Settings()
        return Settings(
            autoAcceptEnabled = this[K.auto] ?: d.autoAcceptEnabled,
            minPriceEnabled = this[K.minOn] ?: d.minPriceEnabled, minPrice = this[K.min] ?: d.minPrice,
            maxPickupEnabled = this[K.maxOn] ?: d.maxPickupEnabled, maxPickupMinutes = this[K.max] ?: d.maxPickupMinutes,
            priceOverrideTimeEnabled = this[K.ovOn] ?: d.priceOverrideTimeEnabled,
            priceOverrideTimeValue = this[K.ov] ?: d.priceOverrideTimeValue,
            shortTripOverrideEnabled = this[K.shortOn] ?: d.shortTripOverrideEnabled,
            acceptNoDestinationEnabled = this[K.noDest] ?: d.acceptNoDestinationEnabled,
            bubbleVisible = this[K.bubble] ?: d.bubbleVisible,
        )
    }
}
