package com.example.replica.ui.triplog

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.replica.domain.AcceptRule
import com.example.replica.domain.Retention
import com.example.replica.domain.TripLogRules
import com.example.replica.domain.TripRecord
import com.example.replica.ui.home.AppCard
import com.example.replica.ui.theme.Tok
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale

// TODO: move to res/values/strings.xml. Layout is a first guess: the original's history screen has not been seen.
private object H {
    const val TITLE = "سجل الرحلات"; const val EMPTY = "لا توجد رحلات مقبولة بعد"
    const val EMPTY_SUB = "الرحلات التي يقبلها التطبيق تلقائياً تظهر هنا."
    const val CLEAR = "مسح السجل"; const val CLEAR_Q = "هل تريد مسح كل الرحلات المسجلة؟ لا يمكن التراجع عن ذلك."
    const val YES = "مسح"; const val NO = "إلغاء"
    const val TODAY = "اليوم"; const val YESTERDAY = "أمس"; const val NO_DEST = "بدون وجهة"
    const val CURRENCY = "د.أ"; const val MIN = "دقائق"
    val FOOTER = "تُحفظ الرحلات على جهازك فقط وتُحذف تلقائياً بعد ${Retention.DAYS} يوماً."
}

@Composable
fun TripLogScreen(vm: TripLogViewModel, onBack: () -> Unit) {
    val trips by vm.trips.collectAsState()
    var confirmClear by remember { mutableStateOf(false) }
    val list = trips

    Column(Modifier.fillMaxSize().background(Tok.bgPage).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "back") }
            Text(H.TITLE, Modifier.weight(1f), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            if (!list.isNullOrEmpty()) IconButton({ confirmClear = true }) { Icon(Icons.Filled.Delete, H.CLEAR, tint = Tok.textSecondary) }
        }
        when {
            list == null -> Unit
            list.isEmpty() -> Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                Icon(Icons.Filled.History, null, Modifier.size(56.dp), tint = Tok.textSecondary)
                Spacer(Modifier.height(12.dp))
                Text(H.EMPTY, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(H.EMPTY_SUB, fontSize = 12.sp, color = Tok.textSecondary, textAlign = TextAlign.Center)
            }
            else -> {
                val groups = remember(list) { TripLogRules.groupByDay(list, ZoneId.systemDefault()) }
                LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    groups.forEach { (day, dayTrips) ->
                        item(key = "day-$day") { Text(dayLabel(day), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Tok.textSecondary) }
                        items(dayTrips, key = { it.id }) { TripCard(it) }
                    }
                    item { Text(H.FOOTER, fontSize = 12.sp, color = Tok.textSecondary) }
                }
            }
        }
    }

    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false },
        title = { Text(H.CLEAR) }, text = { Text(H.CLEAR_Q) },
        confirmButton = { TextButton({ vm.clearAll(); confirmClear = false }) { Text(H.YES) } },
        dismissButton = { TextButton({ confirmClear = false }) { Text(H.NO) } },
    )
}

@Composable
private fun TripCard(t: TripRecord) = AppCard {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(t.destination ?: H.NO_DEST, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            val time = SimpleDateFormat("HH:mm", Locale.US).format(Date(t.acceptedAtMs))
            val pickup = t.pickupMinutes?.let { " · وصول $it ${H.MIN}" } ?: ""
            Text(time + pickup, fontSize = 12.sp, color = Tok.textSecondary)
            ruleLabel(t.rule)?.let {
                Text(it, Modifier.clip(RoundedCornerShape(10.dp)).background(Tok.primaryChip).padding(horizontal = 10.dp, vertical = 3.dp),
                    fontSize = 11.sp, color = Tok.primaryContent)
            }
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(t.price?.let { String.format(Locale.US, "%.2f", it) } ?: "—", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(H.CURRENCY, fontSize = 12.sp, color = Tok.textSecondary)
        }
    }
}

private fun ruleLabel(r: AcceptRule): String? = when (r) {
    AcceptRule.NORMAL -> null
    AcceptRule.PRICE_OVERRIDES_TIME -> "تجاوز الوقت بسبب السعر"
    AcceptRule.SHORT_TRIP_OVERRIDE -> "رحلة قريبة"
    AcceptRule.NO_DESTINATION_TIME_ONLY -> "بدون وجهة"
}

private val ARABIC_LATIN_DIGITS = Locale.Builder().setLanguage("ar").setUnicodeLocaleKeyword("nu", "latn").build()
private val DAY_FORMAT = DateTimeFormatter.ofPattern("EEEE d MMMM", ARABIC_LATIN_DIGITS)

private fun dayLabel(d: LocalDate): String {
    val today = LocalDate.now()
    return when (d) { today -> H.TODAY; today.minusDays(1) -> H.YESTERDAY; else -> d.format(DAY_FORMAT) }
}
