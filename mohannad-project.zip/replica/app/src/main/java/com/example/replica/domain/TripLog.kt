package com.example.replica.domain

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** A trip the app accepted automatically. Android-free; the Room entity maps to and from this. */
data class TripRecord(
    val id: Long = 0,
    val acceptedAtMs: Long,
    val price: Double?,
    val destination: String?,
    val pickupMinutes: Int?,
    val rule: AcceptRule,
    val sourcePackage: String,
)

object Retention {
    const val DAYS = 90
    fun cutoffMs(nowMs: Long, days: Int = DAYS): Long = nowMs - days * 86_400_000L
}

object TripLogRules {
    const val DUPLICATE_WINDOW_MS = 60_000L

    /** Only trips that were accepted AND really clicked are history. Ignored offers and failed clicks are not. */
    fun toRecord(e: DecisionEntry): TripRecord? {
        val d = e.decision
        if (d !is Decision.Accept || e.clicked != true) return null
        return TripRecord(
            acceptedAtMs = e.atMs, price = e.offer.price, destination = e.destination,
            pickupMinutes = e.offer.pickupMinutes, rule = d.rule, sourcePackage = e.sourcePackage,
        )
    }

    /** Same offer from the same app within a minute = the same trip seen twice. */
    fun isDuplicate(last: TripRecord?, new: TripRecord): Boolean =
        last != null && last.price == new.price && last.destination == new.destination &&
            last.pickupMinutes == new.pickupMinutes && last.sourcePackage == new.sourcePackage &&
            new.acceptedAtMs - last.acceptedAtMs in 0 until DUPLICATE_WINDOW_MS

    /** Input must be newest-first; day order and in-day order are kept. */
    fun groupByDay(records: List<TripRecord>, zone: ZoneId): List<Pair<LocalDate, List<TripRecord>>> =
        records.groupBy { Instant.ofEpochMilli(it.acceptedAtMs).atZone(zone).toLocalDate() }.toList()
}
