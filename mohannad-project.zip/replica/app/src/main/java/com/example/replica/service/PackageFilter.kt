package com.example.replica.service

import android.accessibilityservice.AccessibilityService

/**
 * The service can only see the apps listed here: our own package, the ride apps the user switched on,
 * and (only while a dev capture is armed) the apps picked for capture.
 */
class PackageFilter(private val service: AccessibilityService) {
    private var supported: Set<String> = emptySet()
    private var capture: Set<String> = emptySet()

    fun setSupported(packages: Set<String>) { supported = packages; apply() }
    fun setCapture(packages: Set<String>) { capture = packages; apply() }

    private fun apply() {
        val info = service.serviceInfo ?: return
        info.packageNames = (setOf(service.packageName) + supported + capture).toTypedArray()
        service.serviceInfo = info
    }
}
