package com.example.replica.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.replica.data.SettingsRepository
import com.example.replica.data.SupportedAppsStore
import com.example.replica.data.TripLogRepository
import com.example.replica.domain.Settings
import com.example.replica.domain.offer.AppSelection
import com.example.replica.domain.offer.RideApp
import com.example.replica.service.InstalledApp
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HomeViewModel(
    private val repo: SettingsRepository,
    tripLog: TripLogRepository,
    private val apps: SupportedAppsStore,
) : ViewModel() {
    /** Trips accepted since local midnight, for the running card. */
    val todayCount: StateFlow<Int> = tripLog.todayCount().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    val settings: StateFlow<Settings> =
        repo.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), Settings())

    /** package name -> parser, for the ride apps the user switched on. */
    val roles: StateFlow<Map<String, RideApp>> =
        apps.roles.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyMap())

    private fun change(f: (Settings) -> Settings) { viewModelScope.launch { repo.update(f) } }

    fun setAutoAccept(on: Boolean) = change { it.copy(autoAcceptEnabled = on) }
    fun setMinPriceEnabled(on: Boolean) = change { it.copy(minPriceEnabled = on) }
    fun stepMinPrice(delta: Double) = change { it.copy(minPrice = (it.minPrice + delta).coerceAtLeast(0.0)) }
    fun setMaxPickupEnabled(on: Boolean) = change { it.copy(maxPickupEnabled = on) }
    fun stepMaxPickup(delta: Int) = change { it.copy(maxPickupMinutes = (it.maxPickupMinutes + delta).coerceIn(1, 60)) }
    fun setPriceOverrideEnabled(on: Boolean) = change { it.copy(priceOverrideTimeEnabled = on) }
    fun stepPriceOverride(delta: Double) = change { it.copy(priceOverrideTimeValue = (it.priceOverrideTimeValue + delta).coerceAtLeast(0.0)) }
    fun setShortTripOverride(on: Boolean) = change { it.copy(shortTripOverrideEnabled = on) }
    fun setBubbleVisible(on: Boolean) = change { it.copy(bubbleVisible = on) }
    fun setAcceptNoDestination(on: Boolean) = change { it.copy(acceptNoDestinationEnabled = on) }

    /** Flips one ride app on or off. Returns what the screen must do next (for example show the "which app?" list). */
    fun toggleApp(role: RideApp, on: Boolean, candidates: List<InstalledApp>): AppSelection {
        val decision = AppSelection.decide(on, candidates.map { it.packageName })
        when (decision) {
            AppSelection.Disable -> viewModelScope.launch { apps.clearRole(role) }
            is AppSelection.Enable -> viewModelScope.launch { apps.set(decision.packageName, role, true) }
            else -> Unit
        }
        return decision
    }

    fun chooseApp(role: RideApp, packageName: String) { viewModelScope.launch { apps.set(packageName, role, true) } }
}
