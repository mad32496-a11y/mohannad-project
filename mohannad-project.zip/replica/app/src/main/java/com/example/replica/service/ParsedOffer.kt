package com.example.replica.service

import com.example.replica.domain.Offer

/** An offer read from a screen, plus the action that accepts it. Android-free so the pipeline is unit-testable. */
class ParsedOffer(
    val offer: Offer,
    val destination: String?,
    val sourcePackage: String = "",
    val accept: () -> Boolean,
)
