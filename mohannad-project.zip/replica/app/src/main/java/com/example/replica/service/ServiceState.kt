package com.example.replica.service

import com.example.replica.domain.DecisionEntry
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

/** Same-process bridge between AcceptService and the UI. The Room trip log replaces the in-memory list later. */
object ServiceState {
    val connected = MutableStateFlow(false)
    private val _decisions = MutableStateFlow<List<DecisionEntry>>(emptyList())
    val decisions: StateFlow<List<DecisionEntry>> = _decisions

    fun log(e: DecisionEntry) { _decisions.update { (listOf(e) + it).take(20) } }
}
