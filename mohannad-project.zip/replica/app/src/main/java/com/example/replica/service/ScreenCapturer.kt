package com.example.replica.service

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.view.accessibility.AccessibilityNodeInfo
import com.example.replica.data.DumpStore
import com.example.replica.domain.*
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Dev tool: while armed it saves the accessibility tree of the chosen apps so an OfferParser can be written from
 * real data. Privacy: it only runs after you tap the button, only for the packages you picked (the service's
 * packageNames are widened to exactly those, then restored), stops after a time limit or a shot limit, and masks
 * letters by default.
 */
class ScreenCapturer(
    private val service: AccessibilityService,
    private val store: DumpStore,
    private val filter: PackageFilter,
    private val onShot: (candidate: Boolean) -> Unit,
) {
    private var session: CaptureSession? = null
    private var targets: Set<String> = emptySet()
    private var keepRaw = false

    fun start(req: CaptureRequest, nowMs: Long) {
        session = CaptureSession(nowMs + req.durationMs, req.maxShots)
        targets = req.packages
        keepRaw = req.keepRaw
        restrictTo(req.packages)
        CaptureBus.status.value = CaptureStatus(armed = true, untilMs = nowMs + req.durationMs, maxShots = req.maxShots)
    }

    /** Idempotent: calling it again after the session ended changes nothing, so the first message is kept. */
    fun stop(message: String) {
        if (session == null) return
        session = null; targets = emptySet()
        restrictTo(emptySet())
        CaptureBus.status.update { it.copy(armed = false, message = message) }
        CaptureBus.request.value = null
    }

    fun onEvent(nowMs: Long) {
        val s = session ?: return
        if (s.isOver(nowMs)) { stop(if (s.shots >= s.maxShots) "اكتملت اللقطات" else "انتهى الوقت"); return }
        if (!s.shouldTry(nowMs)) return
        for (root in roots()) {
            val pkg = root.packageName?.toString() ?: continue
            if (pkg !in targets) continue
            val raw = root.toDumpNode()
            val hints = OfferHeuristics.analyze(raw)                     // on the raw tree, before masking
            if (!s.accept(nowMs, DumpTools.structureHash(raw), hints.isCandidate)) continue
            save(pkg, nowMs, s.shots, raw, hints)
            CaptureBus.status.update { it.copy(shots = s.shots, candidates = s.candidates) }
            onShot(hints.isCandidate)
            if (s.isOver(nowMs)) { stop("اكتملت اللقطات"); return }
        }
    }

    private fun save(pkg: String, nowMs: Long, shotNo: Int, raw: DumpNode, hints: OfferHints) {
        val dm = service.resources.displayMetrics
        val snapshot = DumpSnapshot(
            pkg = pkg, capturedAtMs = nowMs, redacted = !keepRaw,
            device = mapOf("sdk" to Build.VERSION.SDK_INT.toString(), "screen" to "${dm.widthPixels}x${dm.heightPixels}", "density" to dm.density.toString()),
            hints = hints,
            root = if (keepRaw) DumpRedactor.dropPasswords(raw) else DumpRedactor.redact(raw),
        )
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date(nowMs))
        val name = "${pkg.replace('.', '_')}_${stamp}_${shotNo}${if (hints.isCandidate) "_offer" else ""}.json"
        store.write(name, DumpJson.write(snapshot))
    }

    /** The active window plus every other window (offers are often drawn as an overlay window). */
    private fun roots(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        service.rootInActiveWindow?.let { out += it }
        service.windows?.forEach { w -> w.root?.let { out += it } }
        return out
    }

    /** Widens the service's package filter to the chosen apps only, or back to our own package. */
    private fun restrictTo(extra: Set<String>) = filter.setCapture(extra)
}
