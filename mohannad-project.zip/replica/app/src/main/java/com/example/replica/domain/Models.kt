package com.example.replica.domain

/** One ride offer as read from the screen. null = the field was not shown on the offer. */
data class Offer(val price: Double?, val pickupMinutes: Int?)

/** All user-editable rules. Defaults are the values seen in the original's screenshots. */
data class Settings(
    val autoAcceptEnabled: Boolean = false,
    val minPriceEnabled: Boolean = true,
    val minPrice: Double = 2.0,
    val maxPickupEnabled: Boolean = true,
    val maxPickupMinutes: Int = 5,
    val priceOverrideTimeEnabled: Boolean = false,
    val priceOverrideTimeValue: Double = 0.0,
    val shortTripOverrideEnabled: Boolean = false,
    val acceptNoDestinationEnabled: Boolean = false,
    val bubbleVisible: Boolean = false,
)

enum class AcceptRule { NORMAL, PRICE_OVERRIDES_TIME, SHORT_TRIP_OVERRIDE, NO_DESTINATION_TIME_ONLY }

enum class IgnoreReason {
    AUTO_ACCEPT_OFF, NOT_ENTITLED, INVALID_OFFER, PRICE_TOO_LOW,
    PICKUP_TOO_FAR, PICKUP_UNKNOWN, NO_PRICE_NOT_ALLOWED,
}

sealed interface Decision {
    data class Accept(val rule: AcceptRule) : Decision
    data class Ignore(val reason: IgnoreReason) : Decision
}
