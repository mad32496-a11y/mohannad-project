package com.example.replica.service

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import com.example.replica.domain.offer.AcceptTarget
import com.example.replica.domain.offer.OfferText
import com.example.replica.domain.offer.RideApp
import com.example.replica.domain.offer.ScreenOfferParser

/**
 * Bridge between a live screen and a pure ScreenOfferParser: copy the live tree into a DumpNode tree, let the pure
 * parser decide, and keep a way to press the button it found. [roles] maps package name to the app the user enabled it as.
 */
class DumpBasedOfferParser(
    private val app: RideApp,
    private val roles: () -> Map<String, RideApp>,
    private val parser: ScreenOfferParser,
    private val tap: (x: Int, y: Int) -> Boolean,
) : OfferParser {
    override fun supports(packageName: String) = roles()[packageName] == app

    override fun parse(root: AccessibilityNodeInfo): ParsedOffer? {
        val screen = parser.parse(root.toDumpNode()) ?: return null
        val pkg = root.packageName?.toString().orEmpty()
        return ParsedOffer(screen.offer, screen.destination, pkg) { LiveClicker.press(root, screen.accept, tap) }
    }
}

object LiveClicker {
    /** 1) ACTION_CLICK on the button (or its clickable ancestor). 2) If the app ignores that, tap the button's centre. */
    fun press(root: AccessibilityNodeInfo, target: AcceptTarget, tap: (Int, Int) -> Boolean): Boolean {
        val node = find(root, target) ?: return false
        if (NodeFinder.click(node)) return true
        val r = Rect(); node.getBoundsInScreen(r)
        return !r.isEmpty && tap(r.centerX(), r.centerY())
    }

    private fun find(n: AccessibilityNodeInfo?, t: AcceptTarget): AccessibilityNodeInfo? {
        if (n == null) return null
        val label = (n.text?.toString()?.takeIf { it.isNotBlank() } ?: n.contentDescription?.toString())?.let { OfferText.clean(it) }
        if (label == t.label && n.isVisibleToUser) return n
        for (i in 0 until n.childCount) find(n.getChild(i), t)?.let { return it }
        return null
    }
}
