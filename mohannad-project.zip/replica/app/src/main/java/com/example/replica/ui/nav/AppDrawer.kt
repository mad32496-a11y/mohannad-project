package com.example.replica.ui.nav

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Science
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.replica.domain.DrawerDestination
import com.example.replica.domain.DrawerDestinations
import com.example.replica.ui.theme.Tok

private fun label(d: DrawerDestination) = when (d) {
    DrawerDestination.HOME -> "الرئيسية"
    DrawerDestination.TRIP_LOG -> "سجل الرحلات"
    DrawerDestination.SIMULATOR -> "محاكي العروض (للتطوير)"
}

private fun icon(d: DrawerDestination): ImageVector = when (d) {
    DrawerDestination.HOME -> Icons.Filled.Home
    DrawerDestination.TRIP_LOG -> Icons.Filled.History
    DrawerDestination.SIMULATOR -> Icons.Filled.Science
}

/** Wraps a screen with the side menu. Under RTL it opens from the right edge by itself. */
@Composable
fun AppDrawer(
    drawerState: DrawerState,
    current: DrawerDestination,
    devTools: Boolean,
    versionName: String,
    onNavigate: (DrawerDestination) -> Unit,
    content: @Composable () -> Unit,
) {
    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = Tok.surface) {
                Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Tok.heroStart, Tok.heroEnd))),
                        Alignment.Center,
                    ) { Icon(Icons.Filled.Bolt, null, tint = Color.White) }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("Mohannad", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("تحكم بالطلبات بشكل ذكي", fontSize = 12.sp, color = Tok.textSecondary)
                    }
                }
                Spacer(Modifier.height(8.dp))
                DrawerDestinations.visible(devTools).forEach { d ->
                    NavigationDrawerItem(
                        label = { Text(label(d), fontSize = 16.sp) },
                        icon = { Icon(icon(d), null) },
                        selected = d == current,
                        onClick = { onNavigate(d) },
                        modifier = Modifier.padding(horizontal = 12.dp),
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = Tok.primaryTint, selectedTextColor = Tok.primaryContent,
                            selectedIconColor = Tok.primaryContent, unselectedTextColor = Tok.textPrimary,
                            unselectedIconColor = Tok.textSecondary,
                        ),
                    )
                }
                Spacer(Modifier.weight(1f))
                Text("Mohannad · $versionName", Modifier.padding(20.dp), fontSize = 12.sp, color = Tok.textSecondary)
            }
        },
        content = content,
    )
}
