package com.example.replica.ui.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.replica.domain.Decision
import com.example.replica.domain.DecisionEntry
import com.example.replica.domain.HeroAction
import com.example.replica.domain.HeroState
import com.example.replica.domain.offer.AppSelection
import com.example.replica.domain.offer.AppStatus
import com.example.replica.domain.offer.RideApp
import com.example.replica.domain.primaryAction
import com.example.replica.service.InstalledApp
import com.example.replica.service.ServiceState
import com.example.replica.ui.theme.Tok
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private object S {
    const val APP = "Mohannad"; const val TAGLINE = "تحكم بالطلبات بشكل ذكي"
    const val APPS = "تطبيقات النقل"; const val APPS_SUB = "شغّل كل تطبيق بشكل مستقل. الخدمة ما بتقرأ إلا التطبيقات المفعّلة."
    const val ACCESS = "إمكانية الوصول"; const val ACCESS_SUB = "اضغط لتفعيل الخدمة"
    const val BUBBLE_NEEDS_SERVICE = "فعّل خدمة إمكانية الوصول لتظهر الفقاعة"
    const val BUBBLE = "الفقاعة العائمة"; const val BUBBLE_SUB_ON = "الفقاعة ظاهرة"; const val BUBBLE_SUB_OFF = "الفقاعة مخفية"
    const val CONDITIONS = "شروط قبول الطلب"; const val HINT = "للتعديل − / +"
    const val MIN_PRICE = "الحد الأدنى للسعر"; const val MIN_PRICE_SUB = "أقل سعر مسموح"
    const val MAX_PICKUP = "أقصى وقت للوصول"; const val MAX_PICKUP_SUB = "بالدقائق"
    const val OVERRIDE_HELP = "إذا وصل السعر لهذا الرقم يتم تجاهل شرط الوقت"
    const val OVERRIDE = "سعر تجاوز الوقت"; const val OVERRIDE_SUB = "تجاوز الوقت عند الوصول للسعر"
    const val SHORT = "شرط تجاوز السعر"; const val SHORT_SUB = "قبول طلبات دقيقة أو دقيقتين حتى لو خالفت شروط السعر"
    const val INFO = "مثال: إذا كان سعر التجاوز 7 دنانير، فالطلبات التي سعرها 7 أو أكثر يتم قبولها حتى لو تجاوزت الحد الأقصى للوقت."
    const val NO_DEST = "قبول الطلبات بدون وجهة"; const val NO_DEST_SUB = "الطلبات بدون سعر تمر على شرط الوقت"
    const val HISTORY = "سجل الرحلات"
}

@Composable
fun HomeScreen(
    vm: HomeViewModel,
    installed: Map<RideApp, List<InstalledApp>>,
    onOpenAccessibility: () -> Unit, onOpenBubble: () -> Unit, onOpenHistory: () -> Unit, onMenu: () -> Unit,
) {
    val s by vm.settings.collectAsState()
    val roles by vm.roles.collectAsState()
    val serviceConnected by ServiceState.connected.collectAsState()
    val decisions by ServiceState.decisions.collectAsState()
    val today by vm.todayCount.collectAsState()
    var choosing by remember { mutableStateOf<RideApp?>(null) }

    // the installed package(s) of a ride app that the user switched on
    fun enabledPackages(role: RideApp): Set<String> {
        val here = installed[role].orEmpty().map { it.packageName }.toSet()
        return roles.filterValues { it == role }.keys.filter { it in here }.toSet()
    }
    val anyApp = RideApp.values().any { enabledPackages(it).isNotEmpty() }
    val hero = HeroState.from(s.autoAcceptEnabled, serviceConnected, anyApp)

    Column(
        Modifier.fillMaxSize().background(Tok.bgPage).verticalScroll(rememberScrollState())
            .statusBarsPadding().navigationBarsPadding().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Header(onMenu)
        HeroCard(
            state = hero, autoOn = s.autoAcceptEnabled, todayCount = today, lastDecision = decisions.firstOrNull(),
            onSwitch = { on -> vm.setAutoAccept(on) },
            onPrimary = {
                when (hero.primaryAction) {
                    HeroAction.TURN_ON -> vm.setAutoAccept(true)
                    HeroAction.TURN_OFF -> vm.setAutoAccept(false)
                    HeroAction.OPEN_ACCESSIBILITY -> onOpenAccessibility()
                }
            },
        )

        Spacer(Modifier.height(4.dp))
        Text(S.APPS, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Tok.textPrimary)
        Text(S.APPS_SUB, fontSize = 12.sp, color = Tok.textSecondary)
        RideApp.values().forEach { role ->
            val pkgs = enabledPackages(role)
            val status = AppStatus.of(installed[role].orEmpty().isNotEmpty(), pkgs.isNotEmpty(), serviceConnected, s.autoAcceptEnabled)
            val last = decisions.firstOrNull { it.sourcePackage in pkgs }
            AppMonitorCard(role, status, last, pkgs.isNotEmpty()) { on ->
                when (vm.toggleApp(role, on, installed[role].orEmpty())) {
                    is AppSelection.Choose -> { choosing = role }
                    else -> { }
                }
            }
        }

        NavRow(Icons.Filled.AccessibilityNew, S.ACCESS, S.ACCESS_SUB, onOpenAccessibility)
        NavRow(Icons.Filled.BubbleChart, S.BUBBLE,
            when { !s.bubbleVisible -> S.BUBBLE_SUB_OFF; serviceConnected -> S.BUBBLE_SUB_ON; else -> S.BUBBLE_NEEDS_SERVICE },
        ) { vm.setBubbleVisible(!s.bubbleVisible); onOpenBubble() }

        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(S.CONDITIONS, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Tok.textPrimary)
            Text(S.HINT, Modifier.clip(RoundedCornerShape(12.dp)).background(Tok.primaryChip).padding(horizontal = 12.dp, vertical = 6.dp),
                fontSize = 12.sp, color = Tok.primaryContent)
        }

        ConditionCard(S.MIN_PRICE, S.MIN_PRICE_SUB, s.minPriceEnabled, vm::setMinPriceEnabled,
            fmt(s.minPrice), onMinus = { vm.stepMinPrice(-0.5) }, onPlus = { vm.stepMinPrice(0.5) })
        ConditionCard(S.MAX_PICKUP, S.MAX_PICKUP_SUB, s.maxPickupEnabled, vm::setMaxPickupEnabled,
            s.maxPickupMinutes.toString(), onMinus = { vm.stepMaxPickup(-1) }, onPlus = { vm.stepMaxPickup(1) })
        Text(S.OVERRIDE_HELP, fontSize = 12.sp, color = Tok.textSecondary)
        ConditionCard(S.OVERRIDE, S.OVERRIDE_SUB, s.priceOverrideTimeEnabled, vm::setPriceOverrideEnabled,
            fmt(s.priceOverrideTimeValue), onMinus = { vm.stepPriceOverride(-0.5) }, onPlus = { vm.stepPriceOverride(0.5) })
        ToggleCard(S.SHORT, S.SHORT_SUB, s.shortTripOverrideEnabled, vm::setShortTripOverride)
        InfoBox(S.INFO)
        ToggleCard(S.NO_DEST, S.NO_DEST_SUB, s.acceptNoDestinationEnabled, vm::setAcceptNoDestination, Icons.Filled.LocationOff)

        OutlinedButton(onClick = onOpenHistory, Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(18.dp),
            border = BorderStroke(1.dp, Tok.switchOffOutline)) {
            Icon(Icons.Filled.History, null, tint = Tok.primaryContent); Spacer(Modifier.width(8.dp))
            Text(S.HISTORY, color = Tok.primaryContent, fontWeight = FontWeight.Medium)
        }
    }

    choosing?.let { role ->
        AlertDialog(
            onDismissRequest = { choosing = null },
            title = { Text("اختر تطبيق السائق") },
            text = {
                Column {
                    Text("ظهر أكثر من تطبيق مطابق. اختر تطبيق السائق (مش تطبيق الراكب).", fontSize = 12.sp)
                    installed[role].orEmpty().forEach { a ->
                        TextButton({ vm.chooseApp(role, a.packageName); choosing = null }, Modifier.fillMaxWidth()) {
                            Column(Modifier.fillMaxWidth()) {
                                Text(a.label)
                                Text(a.packageName, fontSize = 11.sp, color = Tok.textSecondary)
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton({ choosing = null }) { Text("إلغاء") } },
        )
    }
}

private data class AppLook(val name: String, val letter: String, val accent: Color, val tint: Color)

private fun look(role: RideApp) = when (role) {
    RideApp.JEENY -> AppLook("جيني · Jeeny", "J", Tok.jeenyAccent, Tok.jeenyTint)
    RideApp.PETRA -> AppLook("بترا · Petra", "P", Tok.petraAccent, Tok.petraTint)
}

private fun statusStyle(s: AppStatus): Triple<String, Color, Color> = when (s) {
    AppStatus.ACTIVE -> Triple("يعمل · يراقب العروض", Tok.successTint, Tok.successText)
    AppStatus.OFF -> Triple("متوقف", Tok.bgPage, Tok.textSecondary)
    AppStatus.MASTER_OFF -> Triple("القبول التلقائي مطفي", Tok.bgPage, Tok.textSecondary)
    AppStatus.NEEDS_SERVICE -> Triple("بانتظار تفعيل خدمة الوصول", Tok.warnTint, Tok.warnText)
    AppStatus.NOT_INSTALLED -> Triple("التطبيق غير مثبت", Tok.warnTint, Tok.warnText)
}

/** One ride app: its own switch, its own status light, and when it last saw an offer. */
@Composable
private fun AppMonitorCard(role: RideApp, status: AppStatus, last: DecisionEntry?, checked: Boolean, onToggle: (Boolean) -> Unit) {
    val look = look(role)
    val (statusText, chipBg, chipFg) = statusStyle(status)
    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).clip(CircleShape).background(look.tint), Alignment.Center) {
                Text(look.letter, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = look.accent)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(look.name, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(chipFg))          // the status light
                    Spacer(Modifier.width(6.dp))
                    Text(statusText, Modifier.clip(RoundedCornerShape(10.dp)).background(chipBg).padding(horizontal = 8.dp, vertical = 3.dp),
                        fontSize = 12.sp, color = chipFg)
                }
                if (last != null) {
                    val time = SimpleDateFormat("HH:mm", Locale.US).format(Date(last.atMs))
                    Text("آخر عرض: $time · ${if (last.decision is Decision.Accept) "قُبل" else "تُجوهل"}", fontSize = 12.sp, color = Tok.textSecondary)
                }
            }
            AppSwitch(checked, onToggle, enabled = status != AppStatus.NOT_INSTALLED)
        }
    }
}

private fun fmt(v: Double) = String.format(Locale.US, "%.1f", v)   // Latin digits, as in the original

@Composable private fun Header(onMenu: () -> Unit) = Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
    Box(Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Tok.heroStart, Tok.heroEnd))), Alignment.Center) {
        Icon(Icons.Filled.Bolt, null, tint = Color.White)
    }
    Spacer(Modifier.width(12.dp))
    Column(Modifier.weight(1f)) {
        Text(S.APP, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Tok.textPrimary)
        Text(S.TAGLINE, fontSize = 14.sp, color = Tok.textSecondary)
    }
    IconButton(onMenu, Modifier.size(44.dp).clip(CircleShape).background(Tok.surface)) { Icon(Icons.Filled.Menu, "menu") }
}

@Composable internal fun AppCard(modifier: Modifier = Modifier, bg: Color = Tok.surface, content: @Composable ColumnScope.() -> Unit) =
    Column(modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(bg)
        .border(1.dp, Tok.borderCard, RoundedCornerShape(16.dp)).padding(16.dp), content = content)

@Composable private fun NavRow(icon: ImageVector, title: String, sub: String, onClick: () -> Unit) =
    AppCard(Modifier.clickable(onClick = onClick)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).clip(CircleShape).background(Tok.surfaceDisabled), Alignment.Center) { Icon(icon, null, tint = Tok.textSecondary) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(sub, fontSize = 12.sp, color = Tok.textSecondary)
            }
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null)
        }
    }

@Composable internal fun AppSwitch(checked: Boolean, onChange: (Boolean) -> Unit, enabled: Boolean = true) = Switch(
    checked, onChange, enabled = enabled,
    colors = SwitchDefaults.colors(
        checkedTrackColor = Tok.successTrack, checkedThumbColor = Tok.successKnob, checkedBorderColor = Tok.successTrack,
        uncheckedTrackColor = Tok.switchOffTrack, uncheckedThumbColor = Tok.switchOffOutline, uncheckedBorderColor = Tok.switchOffOutline,
    ),
)

/** Layout fix vs the original: title + switch on one row, stepper on its own row, so titles never wrap to 3-4 lines. */
@Composable private fun ConditionCard(
    title: String, sub: String, enabled: Boolean, onEnabled: (Boolean) -> Unit,
    value: String, onMinus: () -> Unit, onPlus: () -> Unit,
) = AppCard(bg = if (enabled) Tok.surface else Tok.surfaceDisabled) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(sub, fontSize = 12.sp, color = Tok.textSecondary)
        }
        AppSwitch(enabled, onEnabled)
    }
    Spacer(Modifier.height(12.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
        StepButton("−", onMinus, enabled); ValueField(value); StepButton("+", onPlus, enabled)
    }
}

@Composable private fun StepButton(label: String, onClick: () -> Unit, enabled: Boolean) =
    Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(Tok.primaryTint).clickable(enabled = enabled, onClick = onClick), Alignment.Center) {
        Text(label, fontSize = 22.sp, color = Tok.primaryContent)
    }

@Composable private fun ValueField(text: String) =
    Box(Modifier.width(80.dp).height(46.dp).clip(RoundedCornerShape(10.dp)).background(Tok.surface)
        .border(1.dp, Tok.borderCard, RoundedCornerShape(10.dp)), Alignment.Center) {
        Text(text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }

@Composable private fun ToggleCard(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit, trailing: ImageVector? = null) =
    AppCard(bg = if (checked) Tok.surface else Tok.surfaceDisabled) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(sub, fontSize = 12.sp, color = Tok.textSecondary)
            }
            if (trailing != null) { Icon(trailing, null, tint = Tok.textSecondary); Spacer(Modifier.width(8.dp)) }
            AppSwitch(checked, onChange)
        }
    }

@Composable private fun InfoBox(text: String) =
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Tok.primaryTint).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.Info, null, tint = Tok.primaryContent); Spacer(Modifier.width(12.dp))
        Text(text, fontSize = 13.sp, color = Tok.textSecondary)
    }
