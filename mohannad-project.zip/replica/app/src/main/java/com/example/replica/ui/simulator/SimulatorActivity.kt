package com.example.replica.ui.simulator

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.replica.ui.theme.ReplicaTheme

class SimulatorActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ReplicaTheme { SimulatorScreen { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }
        }
    }
}
