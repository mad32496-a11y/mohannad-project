package com.example.replica.service

import android.content.Intent
import android.content.pm.PackageManager
import com.example.replica.domain.AppMatch
import com.example.replica.domain.offer.RideApp

data class InstalledApp(val label: String, val packageName: String)

object LaunchableApps {
    /**
     * Installed apps with a launcher icon whose name or package matches a keyword. Needs the <queries> launcher intent
     * in the manifest (Android 11+ package visibility).
     */
    fun find(pm: PackageManager, keywords: List<String>): List<InstalledApp> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { InstalledApp(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { AppMatch.matches(it.label, it.packageName, keywords) }
            .distinctBy { it.packageName }
    }
}

/** Installed Jeeny and Petra apps, grouped by which parser reads them. Package ids are looked up, never hard-coded. */
object RideAppDirectory {
    fun find(pm: PackageManager, ownPackage: String): Map<RideApp, List<InstalledApp>> {
        val out = mutableMapOf<RideApp, MutableList<InstalledApp>>()
        for (a in LaunchableApps.find(pm, AppMatch.DEFAULT_KEYWORDS)) {
            if (a.packageName == ownPackage || a.packageName in AppMatch.KNOWN_RIDER_PACKAGES) continue
            RideApp.detect(a.label, a.packageName)?.let { out.getOrPut(it) { mutableListOf() }.add(a) }
        }
        return out
    }
}
