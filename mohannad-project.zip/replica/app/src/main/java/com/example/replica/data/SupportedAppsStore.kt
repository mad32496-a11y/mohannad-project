package com.example.replica.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.replica.domain.offer.RideApp
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.supportedStore by preferencesDataStore(name = "supported_apps")

/** Which installed ride apps the user switched on, and as which parser. Stored as "ROLE|package", one package per role. */
class SupportedAppsStore(private val ctx: Context) {
    private val key = stringSetPreferencesKey("enabled")

    val roles: Flow<Map<String, RideApp>> = ctx.supportedStore.data.map { prefs ->
        prefs[key].orEmpty().mapNotNull { entry ->
            val parts = entry.split('|', limit = 2)
            if (parts.size != 2) null else runCatching { RideApp.valueOf(parts[0]) }.getOrNull()?.let { parts[1] to it }
        }.toMap()
    }

    /** Switching a package on replaces whatever package that role had before. */
    suspend fun set(pkg: String, role: RideApp, on: Boolean) {
        ctx.supportedStore.edit { prefs ->
            val kept = prefs[key].orEmpty()
                .filterNot { it.substringAfter('|') == pkg || it.substringBefore('|') == role.name }.toSet()
            prefs[key] = if (on) kept + "${role.name}|$pkg" else kept
        }
    }

    suspend fun clearRole(role: RideApp) {
        ctx.supportedStore.edit { prefs ->
            prefs[key] = prefs[key].orEmpty().filterNot { it.substringBefore('|') == role.name }.toSet()
        }
    }
}
