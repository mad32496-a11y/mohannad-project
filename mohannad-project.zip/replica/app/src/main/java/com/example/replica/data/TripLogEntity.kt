package com.example.replica.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.replica.domain.AcceptRule
import com.example.replica.domain.TripRecord

@Entity(tableName = "trip_log", indices = [Index("acceptedAtMs")])
data class TripLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val acceptedAtMs: Long,
    val price: Double?,
    val destination: String?,
    val pickupMinutes: Int?,
    val rule: String,
    val sourcePackage: String,
)

fun TripLogEntity.toRecord() = TripRecord(
    id, acceptedAtMs, price, destination, pickupMinutes,
    runCatching { AcceptRule.valueOf(rule) }.getOrDefault(AcceptRule.NORMAL), sourcePackage,
)

fun TripRecord.toEntity() = TripLogEntity(id, acceptedAtMs, price, destination, pickupMinutes, rule.name, sourcePackage)
