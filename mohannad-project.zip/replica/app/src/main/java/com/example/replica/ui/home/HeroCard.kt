package com.example.replica.ui.home

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.replica.domain.Decision
import com.example.replica.domain.DecisionEntry
import com.example.replica.domain.HeroState
import com.example.replica.ui.theme.Tok
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * The big master card.
 *  - STOPPED: purple, pause icon, white "turn on" button
 *  - RUNNING: green gradient, bolt with a pulsing ring, today's count + last offer, outlined "stop" button
 *  - NEEDS_ACCESSIBILITY / NEEDS_APP: purple, says what is missing; the button fixes it or stops
 */
@Composable
internal fun HeroCard(
    state: HeroState,
    autoOn: Boolean,
    todayCount: Int,
    lastDecision: DecisionEntry?,
    onSwitch: (Boolean) -> Unit,
    onPrimary: () -> Unit,
) {
    val running = state == HeroState.RUNNING
    val start by animateColorAsState(if (running) Tok.runningStart else Tok.heroStart, tween(400), label = "heroStart")
    val end by animateColorAsState(if (running) Tok.runningEnd else Tok.heroEnd, tween(400), label = "heroEnd")
    val (icon, status) = when (state) {
        HeroState.STOPPED -> Icons.Filled.Pause to "متوقف"
        HeroState.RUNNING -> Icons.Filled.Bolt to "يعمل"
        HeroState.NEEDS_ACCESSIBILITY -> Icons.Filled.AccessibilityNew to "بانتظار تفعيل الخدمة"
        HeroState.NEEDS_APP -> Icons.Filled.DirectionsCar to "فعّل تطبيق نقل"
    }

    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(start, end))).padding(20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp), Alignment.Center) {
                if (running) PulseRing()
                Box(Modifier.size(52.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.2f)), Alignment.Center) {
                    Icon(icon, null, tint = Tok.onHero)
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("القبول التلقائي", fontSize = 14.sp, color = Tok.onHero)
                // live region: a screen reader announces the change when the state flips
                Text(status, Modifier.semantics { liveRegion = LiveRegionMode.Polite }, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Tok.onHero)
            }
            AppSwitch(autoOn, onSwitch)
        }

        if (running) {
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Chip("رحلات اليوم: $todayCount")
                Chip(lastText(lastDecision), Modifier.weight(1f, fill = false))
            }
        }

        Spacer(Modifier.height(16.dp))
        val label = when (state) {
            HeroState.STOPPED -> "تشغيل القبول التلقائي"
            HeroState.RUNNING, HeroState.NEEDS_APP -> "إيقاف القبول التلقائي"
            HeroState.NEEDS_ACCESSIBILITY -> "فعّل خدمة إمكانية الوصول"
        }
        if (running) {
            OutlinedButton(onPrimary, Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.5.dp, Tok.onHero), colors = ButtonDefaults.outlinedButtonColors(contentColor = Tok.onHero)) {
                Text(label, fontWeight = FontWeight.Bold)
            }
        } else {
            Button(onPrimary, Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Tok.heroButtonText)) {
                Text(label, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun Chip(text: String, modifier: Modifier = Modifier) = Text(
    text, modifier.clip(RoundedCornerShape(12.dp)).background(Color.Black.copy(alpha = 0.18f)).padding(horizontal = 10.dp, vertical = 6.dp),
    fontSize = 12.sp, color = Tok.onHero, maxLines = 1, overflow = TextOverflow.Ellipsis,
)

/** The decision log is in memory, so after a process restart this shows "waiting" until the next offer. */
private fun lastText(e: DecisionEntry?): String {
    if (e == null) return "بانتظار أول عرض"
    val time = SimpleDateFormat("HH:mm", Locale.US).format(Date(e.atMs))
    return "آخر عرض: $time · ${if (e.decision is Decision.Accept) "قُبل" else "تُجوهل"}"
}

@Composable
private fun PulseRing() {
    val t = rememberInfiniteTransition(label = "pulse")
    val scale by t.animateFloat(1f, 1.45f, infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Restart), label = "scale")
    val alpha by t.animateFloat(0.35f, 0f, infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Restart), label = "alpha")
    Box(Modifier.size(52.dp).graphicsLayer { scaleX = scale; scaleY = scale; this.alpha = alpha }.background(Color.White, CircleShape))
}
