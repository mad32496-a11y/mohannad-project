package com.example.replica.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TripLogDao {
    @Insert suspend fun insert(e: TripLogEntity): Long

    @Query("SELECT * FROM trip_log ORDER BY acceptedAtMs DESC LIMIT 500")
    fun observeAll(): Flow<List<TripLogEntity>>

    @Query("SELECT * FROM trip_log ORDER BY acceptedAtMs DESC LIMIT 1")
    suspend fun latest(): TripLogEntity?

    @Query("SELECT COUNT(*) FROM trip_log WHERE acceptedAtMs >= :sinceMs")
    fun countSince(sinceMs: Long): Flow<Int>

    @Query("DELETE FROM trip_log WHERE acceptedAtMs < :cutoffMs")
    suspend fun deleteOlderThan(cutoffMs: Long): Int

    @Query("DELETE FROM trip_log")
    suspend fun deleteAll()
}
