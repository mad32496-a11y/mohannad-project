package com.example.replica.ui.triplog

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.replica.data.TripLogRepository
import com.example.replica.ui.theme.ReplicaTheme

class TripLogActivity : ComponentActivity() {
    private val vm: TripLogViewModel by viewModels {
        viewModelFactory { initializer { TripLogViewModel(TripLogRepository.from(applicationContext)) } }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ReplicaTheme { TripLogScreen(vm, onBack = ::finish) } }
    }
}
