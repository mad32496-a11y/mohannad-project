package com.example.replica.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

/** Values from replica/design/tokens.json ("color_clone", WCAG AA). Rebrand in /replica-brand. */
object Tok {
    val bgPage = Color(0xFFF5F6FA); val surface = Color(0xFFFFFFFF); val surfaceDisabled = Color(0xFFF3F3F5)
    val borderCard = Color(0xFFE6EAEA)
    val primary = Color(0xFF674ECE); val primaryContent = Color(0xFF6552BE)
    val primaryTint = Color(0xFFF2EEFE); val primaryChip = Color(0xFFEEEAFE)
    val heroStart = Color(0xFF6A4ECE); val heroEnd = Color(0xFF7A62DD); val onHero = Color.White
    val heroButtonText = Color(0xFF5B45C0)
    val successTrack = Color(0xFF2E7D46); val successKnob = Color.White
    val successText = Color(0xFF367D44); val successTint = Color(0xFFEAF6EE)
    val switchOffTrack = Color(0xFFE6E2EA); val switchOffOutline = Color(0xFF7A767E)
    // ride-app cards (contrast checked: 4.6:1 to 6.1:1 on their tints)
    val jeenyAccent = Color(0xFF6552BE); val jeenyTint = Color(0xFFF2EEFE)
    val petraAccent = Color(0xFFB45309); val petraTint = Color(0xFFFFF4E5)
    val warnText = Color(0xFF8A4B00); val warnTint = Color(0xFFFFF1DC)
    val runningStart = Color(0xFF2E7D46); val runningEnd = Color(0xFF31864B)   // our design: running state
    val textPrimary = Color.Black; val textSecondary = Color(0xFF6F7074)
}

@Composable
fun ReplicaTheme(content: @Composable () -> Unit) {
    // Light only for now: dark mode was not measured (see tokens.json "unmeasured").
    @Suppress("UNUSED_VARIABLE") val dark = isSystemInDarkTheme()
    val scheme = lightColorScheme(
        primary = Tok.primary, onPrimary = Color.White,
        background = Tok.bgPage, surface = Tok.surface,
        onBackground = Tok.textPrimary, onSurface = Tok.textPrimary,
    )
    // The app is Arabic-first, so force RTL.
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
