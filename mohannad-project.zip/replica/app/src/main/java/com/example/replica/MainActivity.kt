package com.example.replica

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.replica.data.SettingsRepository
import com.example.replica.data.SupportedAppsStore
import com.example.replica.data.TripLogRepository
import com.example.replica.domain.DrawerDestination
import com.example.replica.domain.offer.RideApp
import com.example.replica.service.InstalledApp
import com.example.replica.service.RideAppDirectory
import com.example.replica.ui.home.HomeScreen
import com.example.replica.ui.home.HomeViewModel
import com.example.replica.ui.nav.AppDrawer
import com.example.replica.ui.simulator.SimulatorActivity
import com.example.replica.ui.theme.ReplicaTheme
import com.example.replica.ui.triplog.TripLogActivity
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val vm: HomeViewModel by viewModels {
        viewModelFactory {
            initializer {
                HomeViewModel(
                    SettingsRepository(applicationContext), TripLogRepository.from(applicationContext), SupportedAppsStore(applicationContext),
                )
            }
        }
    }

    /** Installed Jeeny and Petra apps. Refreshed every time the screen comes back, in case one was just installed. */
    private var installed by mutableStateOf<Map<RideApp, List<InstalledApp>>>(emptyMap())
    private val devTools get() = (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        installed = RideAppDirectory.find(packageManager, packageName)
        val versionName = runCatching { packageManager.getPackageInfo(packageName, 0).versionName }.getOrNull() ?: ""
        setContent {
            ReplicaTheme {
                val drawerState = rememberDrawerState(DrawerValue.Closed)
                val scope = rememberCoroutineScope()
                BackHandler(enabled = drawerState.isOpen) { scope.launch { drawerState.close() } }

                AppDrawer(
                    drawerState = drawerState, current = DrawerDestination.HOME, devTools = devTools, versionName = versionName,
                    onNavigate = { d -> scope.launch { drawerState.close() }; open(d) },
                ) {
                    HomeScreen(
                        vm = vm,
                        installed = installed,
                        onOpenAccessibility = { startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS)) },
                        onOpenBubble = {},
                        onOpenHistory = { open(DrawerDestination.TRIP_LOG) },
                        onMenu = { scope.launch { drawerState.open() } },
                    )
                }
            }
        }
    }

    /** One place that knows which screen each menu entry opens. Home is this screen, so it does nothing. */
    private fun open(d: DrawerDestination) {
        val target = when (d) {
            DrawerDestination.HOME -> return
            DrawerDestination.TRIP_LOG -> TripLogActivity::class.java
            DrawerDestination.SIMULATOR -> SimulatorActivity::class.java
        }
        startActivity(Intent(this, target))
    }

    override fun onResume() {
        super.onResume()
        installed = RideAppDirectory.find(packageManager, packageName)
    }
}
