package com.example.replica.service

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import com.example.replica.domain.DumpNode

private const val MAX_DEPTH = 40
private const val MAX_NODES = 2_000   // safety cap so a huge screen cannot stall the service

fun AccessibilityNodeInfo.toDumpNode(): DumpNode = convert(this, 0, intArrayOf(MAX_NODES))

private fun convert(n: AccessibilityNodeInfo, depth: Int, budget: IntArray): DumpNode {
    budget[0]--
    val r = Rect(); n.getBoundsInScreen(r)
    val kids = ArrayList<DumpNode>()
    if (depth < MAX_DEPTH) {
        for (i in 0 until n.childCount) {
            if (budget[0] <= 0) break
            val c = n.getChild(i) ?: continue
            kids += convert(c, depth + 1, budget)
        }
    }
    return DumpNode(
        className = n.className?.toString(), resourceId = n.viewIdResourceName,
        text = n.text?.toString(), contentDesc = n.contentDescription?.toString(), hint = n.hintText?.toString(),
        bounds = listOf(r.left, r.top, r.right, r.bottom),
        clickable = n.isClickable, enabled = n.isEnabled, checkable = n.isCheckable, checked = n.isChecked,
        editable = n.isEditable, password = n.isPassword, visible = n.isVisibleToUser, children = kids,
    )
}
