package com.example.replica.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.content.Intent
import android.content.res.Configuration
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import com.example.replica.MainActivity
import com.example.replica.data.DumpStore
import com.example.replica.data.SettingsRepository
import com.example.replica.data.SupportedAppsStore
import com.example.replica.data.TripLogRepository
import com.example.replica.domain.Settings
import com.example.replica.domain.TripLogRules
import com.example.replica.domain.offer.JeenyScreenParser
import com.example.replica.domain.offer.PetraScreenParser
import com.example.replica.domain.offer.RideApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class AcceptService : AccessibilityService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    @Volatile private var settings = Settings()
    private lateinit var parsers: List<OfferParser>
    private lateinit var pipeline: OfferPipeline
    private lateinit var bubble: BubbleController
    private var capturer: ScreenCapturer? = null
    @Volatile private var roles: Map<String, RideApp> = emptyMap()   // package -> parser, set by the user in the supported-apps list

    override fun onServiceConnected() {
        super.onServiceConnected()
        val settingsRepo = SettingsRepository(applicationContext)
        val tripLog = TripLogRepository.from(applicationContext)

        bubble = BubbleController(
            service = this,
            onToggle = { scope.launch { settingsRepo.update { it.copy(autoAcceptEnabled = !it.autoAcceptEnabled) } } },
            onLongPress = { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) },
        )
        parsers = listOf(
            SimulatorOfferParser(packageName),
            // written from screenshots only, NOT verified on a real device: see architecture.md section 10
            DumpBasedOfferParser(RideApp.JEENY, { roles }, JeenyScreenParser(), ::tap),
            DumpBasedOfferParser(RideApp.PETRA, { roles }, PetraScreenParser(), ::tap),
        )
        pipeline = OfferPipeline(
            settings = { settings },
            entitled = { true },   // no trial and no subscription: access is always on
            onDecision = { entry ->
                ServiceState.log(entry)
                TripLogRules.toRecord(entry)?.let { scope.launch { tripLog.record(it) }; bubble.pulse() }
            },
        )
        scope.launch { tripLog.prune() }
        scope.launch { settingsRepo.settings.collect { settings = it; bubble.render(it.bubbleVisible, it.autoAcceptEnabled) } }
        scope.launch { tripLog.todayCount().collect { bubble.setBadge(it) } }
        // dev capture tool: armed from the Offer Simulator screen, runs only for the packages the user picked
        val filter = PackageFilter(this)
        scope.launch { SupportedAppsStore(applicationContext).roles.collect { roles = it; filter.setSupported(it.keys) } }
        val cap = ScreenCapturer(this, DumpStore(applicationContext), filter) { candidate ->
            bubble.pulse()
            if (candidate) Toast.makeText(this, "التُقطت شاشة عرض محتملة", Toast.LENGTH_SHORT).show()
        }
        capturer = cap
        scope.launch {
            CaptureBus.request.collectLatest { r ->
                if (r == null) cap.stop("تم الإيقاف")
                else { cap.start(r, System.currentTimeMillis()); delay(r.durationMs); cap.stop("انتهى الوقت") }
            }
        }
        ServiceState.connected.value = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        capturer?.onEvent(System.currentTimeMillis())    // capture mode works even when auto-accept is off
        if (!settings.autoAcceptEnabled) return          // cheap exit: do not even read the screen when off
        val root = rootInActiveWindow ?: return
        try {
            val pkg = root.packageName?.toString() ?: return
            val parser = parsers.firstOrNull { it.supports(pkg) } ?: return
            val parsed = parser.parse(root) ?: return
            pipeline.handle(parsed)
        } finally {
            @Suppress("DEPRECATION") root.recycle()
        }
    }

    /** Fallback when an app ignores ACTION_CLICK: a 50 ms tap at a screen point. Needs canPerformGestures. */
    private fun tap(x: Int, y: Int): Boolean {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 50)).build()
        return dispatchGesture(gesture, null, null)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::bubble.isInitialized) bubble.onScreenChanged()
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        capturer?.stop("الخدمة توقفت")
        if (::bubble.isInitialized) bubble.hide()
        ServiceState.connected.value = false
        scope.cancel()
        return super.onUnbind(intent)
    }
}
